
-- Issue categories
CREATE TABLE public.issue_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Departments
CREATE TABLE public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Department emails (multiple per department)
CREATE TABLE public.department_emails (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id UUID REFERENCES public.departments(id) ON DELETE CASCADE NOT NULL,
  email TEXT NOT NULL,
  is_boss BOOLEAN NOT NULL DEFAULT false,
  label TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Category to department mapping
CREATE TABLE public.category_department_map (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.issue_categories(id) ON DELETE CASCADE NOT NULL,
  department_id UUID REFERENCES public.departments(id) ON DELETE CASCADE NOT NULL,
  UNIQUE(category_id, department_id)
);

-- Site issues
CREATE TABLE public.site_issues (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  site_id TEXT NOT NULL,
  site_name TEXT NOT NULL,
  site_code TEXT,
  site_location TEXT,
  reporter_name TEXT NOT NULL,
  reporter_department TEXT,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'Medium',
  status TEXT NOT NULL DEFAULT 'Open',
  officer_name TEXT,
  root_cause TEXT,
  action_taken TEXT,
  date_reported TIMESTAMPTZ NOT NULL DEFAULT now(),
  date_assigned TIMESTAMPTZ,
  date_closed TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Issue photos
CREATE TABLE public.issue_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id UUID REFERENCES public.site_issues(id) ON DELETE CASCADE NOT NULL,
  photo_url TEXT NOT NULL,
  caption TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Email notification log
CREATE TABLE public.issue_email_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id UUID REFERENCES public.site_issues(id) ON DELETE CASCADE NOT NULL,
  email_type TEXT NOT NULL,
  recipients TEXT[] NOT NULL,
  cc_recipients TEXT[],
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Seed default categories
INSERT INTO public.issue_categories (name) VALUES
  ('Access Issue'),
  ('Safety Concern'),
  ('Equipment Problem'),
  ('Power Issue'),
  ('Network Issue'),
  ('Other');

-- Seed default departments
INSERT INTO public.departments (name) VALUES
  ('Site Acquisition'),
  ('Network Operations'),
  ('Maintenance'),
  ('Safety & Compliance'),
  ('Management');

-- Storage bucket for issue photos
INSERT INTO storage.buckets (id, name, public) VALUES ('issue-photos', 'issue-photos', true);

-- Storage RLS: allow anyone to upload/read (no auth yet)
CREATE POLICY "Allow public read issue photos" ON storage.objects FOR SELECT USING (bucket_id = 'issue-photos');
CREATE POLICY "Allow public insert issue photos" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'issue-photos');
