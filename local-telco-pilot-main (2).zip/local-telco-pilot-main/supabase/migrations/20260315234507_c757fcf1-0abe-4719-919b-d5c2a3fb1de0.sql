
-- Enable RLS on all tables with permissive policies (no auth yet)
ALTER TABLE public.issue_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.department_emails ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.category_department_map ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_issues ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.issue_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.issue_email_log ENABLE ROW LEVEL SECURITY;

-- Public access policies (will be tightened when auth is added)
CREATE POLICY "Allow all on issue_categories" ON public.issue_categories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on departments" ON public.departments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on department_emails" ON public.department_emails FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on category_department_map" ON public.category_department_map FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on site_issues" ON public.site_issues FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on issue_photos" ON public.issue_photos FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on issue_email_log" ON public.issue_email_log FOR ALL USING (true) WITH CHECK (true);
