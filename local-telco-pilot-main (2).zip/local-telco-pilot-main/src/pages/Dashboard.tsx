import { getSites, getLessors, getLeases, getLeaseAlerts, getPayments } from '@/lib/store';
import { Radio, Users, FileText, CheckCircle, Clock, AlertTriangle, CreditCard, MapPin, ScanLine } from 'lucide-react';
import DocumentScanModal from '@/components/DocumentScanModal';
import { Link } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

export default function Dashboard() {
  const [showScan, setShowScan] = useState(false);
  const [, setRefresh] = useState(0);
  const sites = getSites();
  const lessors = getLessors();
  const leases = getLeases();
  const payments = getPayments();
  const alerts = getLeaseAlerts();
  const active = sites.filter(s => s.status === 'Active').length;
  const pending = sites.filter(s => s.status === 'Pending').length;
  const activeLeases = leases.filter(l => {
    if (!l.endDate) return true;
    return new Date(l.endDate) > new Date();
  }).length;

  const stats = [
    { label: 'Total Sites', value: sites.length, icon: Radio, color: 'text-primary' },
    { label: 'Active Sites', value: active, icon: CheckCircle, color: 'text-success' },
    { label: 'Pending Sites', value: pending, icon: Clock, color: 'text-warning' },
    { label: 'Total Lessors', value: lessors.length, icon: Users, color: 'text-primary' },
    { label: 'Active Leases', value: activeLeases, icon: FileText, color: 'text-primary' },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="page-title">Dashboard</h1>
        <button className="btn-primary gap-2" onClick={() => setShowScan(true)}><ScanLine size={16} /> Scan Document</button>
      </div>

      {showScan && <DocumentScanModal onClose={() => setShowScan(false)} onComplete={() => setRefresh(r => r + 1)} />}

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        {stats.map(s => (
          <div key={s.label} className="stat-card-primary">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">{s.label}</span>
              <s.icon size={18} className={s.color} />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Lease Alerts */}
      {alerts.length > 0 && (
        <div className="bg-card border rounded-lg p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={18} className="text-warning" />
            <h2 className="font-semibold text-foreground">Lease Expiry Alerts</h2>
            <span className="alert-badge bg-warning/20 text-warning">{alerts.length}</span>
          </div>
          <div className="space-y-2">
            {alerts.slice(0, 8).map(a => (
              <div key={a.lease.id} className={`flex items-center justify-between p-3 rounded-md border ${
                a.severity === 'critical' ? 'bg-destructive/5 border-destructive/20' :
                a.severity === 'warning' ? 'bg-warning/5 border-warning/20' :
                'bg-info/5 border-info/20'
              }`}>
                <div className="flex items-center gap-3">
                  <span className={`alert-badge ${
                    a.severity === 'critical' ? 'bg-destructive/20 text-destructive' :
                    a.severity === 'warning' ? 'bg-warning/20 text-warning' :
                    'bg-info/20 text-info'
                  }`}>
                    {a.daysLeft <= 90 ? '< 3mo' : a.daysLeft <= 180 ? '< 6mo' : '< 12mo'}
                  </span>
                  <span className="text-sm font-medium text-foreground">{a.siteName}</span>
                </div>
                <span className="text-xs text-muted-foreground">{a.daysLeft} days left · Ends {a.lease.endDate}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <RecentList title="Recent Sites" items={sites.slice(-5).reverse().map(s => ({ id: s.id, label: s.name, sub: s.province }))} link="/sites" />
        <RecentList title="Recent Leases" items={leases.slice(-5).reverse().map(l => {
          const site = sites.find(s => s.id === l.siteId);
          return { id: l.id, label: site?.name || 'Unknown', sub: l.monthlyPayment };
        })} link="/leases" />
        <div className="bg-card border rounded-lg p-5">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-foreground flex items-center gap-2"><CreditCard size={16} /> Recent Payments</h2>
            <Link to="/payments" className="text-xs text-primary hover:underline">View All</Link>
          </div>
          {payments.length === 0 ? <p className="text-sm text-muted-foreground">No payments yet</p> :
            <ul className="space-y-3">
              {payments.slice(-5).reverse().map(p => {
                const site = sites.find(s => s.id === p.siteId);
                return (
                  <li key={p.id} className="flex justify-between text-sm items-center">
                    <span className="text-foreground font-medium">{site?.name || 'N/A'}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">{p.amount}</span>
                      <span className={`alert-badge ${
                        p.status === 'Paid' ? 'bg-success/20 text-success' :
                        p.status === 'Overdue' ? 'bg-destructive/20 text-destructive' :
                        'bg-warning/20 text-warning'
                      }`}>{p.status}</span>
                    </div>
                  </li>
                );
              })}
            </ul>
          }
        </div>
      </div>

      {/* Mini Map */}
      <div className="bg-card border rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4">
          <MapPin size={16} className="text-primary" />
          <h2 className="font-semibold text-foreground">Site Locations</h2>
        </div>
        <MiniMap sites={sites} />
      </div>
    </div>
  );
}

function MiniMap({ sites }: { sites: any[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }
    const map = L.map(ref.current).setView([-6.0, 147.0], 6);
    mapRef.current = map;
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OSM' }).addTo(map);

    const bounds: L.LatLngExpression[] = [];
    sites.forEach(site => {
      const lat = parseFloat(site.latitude);
      const lng = parseFloat(site.longitude);
      if (isNaN(lat) || isNaN(lng)) return;
      bounds.push([lat, lng]);
      L.marker([lat, lng]).addTo(map).bindPopup(`<b>${site.name}</b><br/>${site.address}`);
    });
    if (bounds.length > 0) map.fitBounds(bounds as L.LatLngBoundsExpression, { padding: [20, 20], maxZoom: 10 });

    return () => { map.remove(); mapRef.current = null; };
  }, [sites]);

  return <div ref={ref} className="w-full h-[250px] rounded-lg border" />;
}

function RecentList({ title, items, link }: { title: string; items: { id: string; label: string; sub: string }[]; link: string }) {
  return (
    <div className="bg-card border rounded-lg p-5">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-semibold text-foreground">{title}</h2>
        <Link to={link} className="text-xs text-primary hover:underline">View All</Link>
      </div>
      {items.length === 0 ? <p className="text-sm text-muted-foreground">No items yet</p> :
        <ul className="space-y-3">
          {items.map(i => (
            <li key={i.id} className="flex justify-between text-sm">
              <span className="text-foreground font-medium">{i.label}</span>
              <span className="text-muted-foreground">{i.sub}</span>
            </li>
          ))}
        </ul>
      }
    </div>
  );
}
