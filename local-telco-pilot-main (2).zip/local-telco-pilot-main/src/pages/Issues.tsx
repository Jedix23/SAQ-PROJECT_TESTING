import { useState, useEffect, useMemo } from 'react';
import { fetchIssues, SiteIssue } from '@/lib/issues';
import { getSites } from '@/lib/store';
import IssueDetailModal from '@/components/issues/IssueDetailModal';
import ReportIssueModal from '@/components/issues/ReportIssueModal';
import { AlertTriangle, Search, Filter, Plus, Eye, Clock, CheckCircle, AlertCircle, ArrowUpDown } from 'lucide-react';
import { Site } from '@/lib/types';

const priorityColors: Record<string, string> = {
  High: 'bg-destructive/15 text-destructive border-destructive/20',
  Medium: 'bg-warning/15 text-warning border-warning/20',
  Low: 'bg-success/15 text-success border-success/20',
};
const statusColors: Record<string, string> = {
  Open: 'bg-destructive/15 text-destructive border-destructive/20',
  'Work In Progress': 'bg-info/15 text-info border-info/20',
  'Waiting for Approval': 'bg-warning/15 text-warning border-warning/20',
  Resolved: 'bg-success/15 text-success border-success/20',
};

export default function Issues() {
  const [issues, setIssues] = useState<SiteIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [selectedIssue, setSelectedIssue] = useState<SiteIssue | null>(null);
  const [reportSite, setReportSite] = useState<Site | null>(null);
  const [showSiteSelect, setShowSiteSelect] = useState(false);
  const sites = getSites();

  const loadIssues = async () => {
    setLoading(true);
    try {
      const data = await fetchIssues({ status: statusFilter, priority: priorityFilter });
      setIssues(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadIssues(); }, [statusFilter, priorityFilter]);

  const filtered = useMemo(() => {
    if (!search) return issues;
    const q = search.toLowerCase();
    return issues.filter(i =>
      i.site_name.toLowerCase().includes(q) ||
      i.site_code?.toLowerCase().includes(q) ||
      i.reporter_name.toLowerCase().includes(q) ||
      i.category.toLowerCase().includes(q) ||
      i.description.toLowerCase().includes(q)
    );
  }, [issues, search]);

  const stats = useMemo(() => ({
    total: issues.length,
    open: issues.filter(i => i.status === 'Open').length,
    inProgress: issues.filter(i => i.status === 'Work In Progress' || i.status === 'Waiting for Approval').length,
    resolved: issues.filter(i => i.status === 'Resolved').length,
  }), [issues]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Site Issues</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Track and manage site acquisition issues</p>
        </div>
        <button className="btn-primary gap-2" onClick={() => setShowSiteSelect(true)}>
          <Plus size={16} /> Report Issue
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={<AlertTriangle size={20} />} label="Total Issues" value={stats.total} color="primary" />
        <StatCard icon={<AlertCircle size={20} />} label="Open" value={stats.open} color="destructive" />
        <StatCard icon={<Clock size={20} />} label="In Progress" value={stats.inProgress} color="warning" />
        <StatCard icon={<CheckCircle size={20} />} label="Resolved" value={stats.resolved} color="success" />
      </div>

      {/* Filters */}
      <div className="rounded-lg border bg-card p-4">
        <div className="flex items-center gap-2 text-sm font-medium text-foreground mb-3">
          <Filter size={15} /> Filters
        </div>
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input className="form-input pl-9" placeholder="Search issues..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="form-input md:w-44" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Open">Open</option>
            <option value="Work In Progress">Work In Progress</option>
            <option value="Waiting for Approval">Waiting for Approval</option>
            <option value="Resolved">Resolved</option>
          </select>
          <select className="form-input md:w-36" value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}>
            <option value="All">All Priority</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg border bg-card overflow-hidden">
        <div className="p-4 border-b">
          <span className="text-sm font-medium text-foreground">{filtered.length} issue{filtered.length !== 1 ? 's' : ''}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <th className="text-left p-3 font-medium text-muted-foreground">Site</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Category</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Reporter</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Priority</th>
                <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Date</th>
                <th className="p-3 font-medium text-muted-foreground text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="p-12 text-center text-muted-foreground">Loading...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={7} className="p-12 text-center text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <AlertTriangle size={32} className="opacity-30" />
                    <span>No issues found</span>
                  </div>
                </td></tr>
              ) : filtered.map(issue => (
                <tr key={issue.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3">
                    <div className="font-medium text-foreground">{issue.site_name}</div>
                    <div className="text-xs text-muted-foreground">{issue.site_code}</div>
                  </td>
                  <td className="p-3 text-muted-foreground">{issue.category}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{issue.reporter_name}</td>
                  <td className="p-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${priorityColors[issue.priority] || ''}`}>
                      {issue.priority}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${statusColors[issue.status] || ''}`}>
                      {issue.status}
                    </span>
                  </td>
                  <td className="p-3 text-muted-foreground text-xs hidden lg:table-cell">
                    {new Date(issue.date_reported).toLocaleDateString()}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1 justify-end">
                      <button onClick={() => setSelectedIssue(issue)} className="p-1.5 rounded-md hover:bg-muted transition-colors" title="View/Respond">
                        <Eye size={15} className="text-muted-foreground" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {selectedIssue && (
        <IssueDetailModal issue={selectedIssue} onClose={() => setSelectedIssue(null)} onUpdated={loadIssues} />
      )}

      {showSiteSelect && (
        <SiteSelectModal sites={sites} onSelect={site => { setReportSite(site); setShowSiteSelect(false); }} onClose={() => setShowSiteSelect(false)} />
      )}

      {reportSite && (
        <ReportIssueModal site={reportSite} onClose={() => setReportSite(null)} onCreated={loadIssues} />
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    primary: 'bg-primary/10 text-primary',
    destructive: 'bg-destructive/10 text-destructive',
    warning: 'bg-warning/10 text-warning',
    success: 'bg-success/10 text-success',
  };
  return (
    <div className="rounded-lg border bg-card p-4 flex items-center gap-3">
      <div className={`rounded-lg p-2.5 ${colorMap[color]}`}>{icon}</div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function SiteSelectModal({ sites, onSelect, onClose }: { sites: any[]; onSelect: (s: any) => void; onClose: () => void }) {
  const [search, setSearch] = useState('');
  const filtered = sites.filter(s => !search || s.name.toLowerCase().includes(search.toLowerCase()) || s.code.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-xl shadow-xl w-full max-w-md max-h-[80vh] overflow-hidden border">
        <div className="p-5 border-b">
          <h2 className="text-lg font-bold text-foreground">Select Site</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Choose a site to report an issue for</p>
          <div className="relative mt-3">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input className="form-input pl-9" placeholder="Search sites..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>
        <div className="overflow-y-auto max-h-[50vh] p-2">
          {filtered.map(s => (
            <button key={s.id} onClick={() => onSelect(s)} className="w-full text-left px-3 py-2.5 rounded-md hover:bg-muted transition-colors">
              <div className="font-medium text-sm text-foreground">{s.name}</div>
              <div className="text-xs text-muted-foreground">{s.code} · {s.province}</div>
            </button>
          ))}
          {filtered.length === 0 && <p className="p-4 text-center text-sm text-muted-foreground">No sites found</p>}
        </div>
        <div className="p-3 border-t">
          <button onClick={onClose} className="btn-secondary w-full">Cancel</button>
        </div>
      </div>
    </div>
  );
}
