import { useState, useRef, useMemo } from 'react';
import { getLeases, addLease, updateLease, deleteLease, getSites, getLessors, exportToCSV, calculateEscalatedRent } from '@/lib/store';
import { Lease } from '@/lib/types';
import DocumentScanModal from '@/components/DocumentScanModal';
import { Plus, Pencil, Trash2, Eye, X, Upload, FileText, Download, Search, TrendingUp, ScanLine } from 'lucide-react';

const empty: Lease = { id: '', siteId: '', lessorId: '', startDate: '', endDate: '', leaseTerm: '', monthlyPayment: '', gstApplicable: false, rentalRate: '', installments: '', amountPayable: '', rentalIncrease: '', sgRate: '', sgStartDate: '', specialRemarks: '', escalationType: 'None', escalationStartYear: 6, escalationRate: 0, escalationInterval: 1 };

export default function Leases() {
  const [leases, setLeases] = useState(getLeases);
  const [editing, setEditing] = useState<Lease | null>(null);
  const [viewing, setViewing] = useState<Lease | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [showScan, setShowScan] = useState(false);
  const [search, setSearch] = useState('');
  const sites = getSites();
  const lessors = getLessors();

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return leases;
    return leases.filter(l => {
      const site = sites.find(s => s.id === l.siteId);
      const lessor = lessors.find(x => x.id === l.lessorId);
      return (site?.name || '').toLowerCase().includes(q) ||
        (lessor?.fullName || '').toLowerCase().includes(q) ||
        l.startDate.includes(q) || l.endDate.includes(q) ||
        l.monthlyPayment.toLowerCase().includes(q);
    });
  }, [leases, search, sites, lessors]);

  const save = (l: Lease) => {
    // Auto-calculate end date
    if (l.startDate && l.leaseTerm) {
      const start = new Date(l.startDate);
      const years = parseInt(l.leaseTerm);
      if (!isNaN(years)) {
        const end = new Date(start);
        end.setFullYear(end.getFullYear() + years);
        l.endDate = end.toISOString().split('T')[0];
      }
    }
    if (l.id) { updateLease(l); } else { l.id = crypto.randomUUID(); addLease(l); }
    setLeases(getLeases());
    setEditing(null);
    setShowForm(false);
  };

  const remove = (id: string) => { if (confirm('Delete this lease?')) { deleteLease(id); setLeases(getLeases()); } };

  const handleExport = () => {
    exportToCSV(leases.map(l => {
      const site = sites.find(s => s.id === l.siteId);
      const lessor = lessors.find(x => x.id === l.lessorId);
      return {
        Site: site?.name || '', Lessor: lessor?.fullName || '',
        StartDate: l.startDate, EndDate: l.endDate, LeaseTerm: l.leaseTerm,
        MonthlyPayment: l.monthlyPayment, GST: l.gstApplicable ? 'Yes' : 'No',
        Escalation: l.escalationType || 'None',
      };
    }), 'leases.csv');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="page-title">Leases</h1>
        <div className="flex gap-2">
          <button className="btn-primary gap-2" onClick={() => setShowScan(true)}><ScanLine size={16} /> Scan Document</button>
          <button className="btn-secondary gap-2" onClick={handleExport}><Download size={16} /> Export CSV</button>
          <button className="btn-secondary gap-2" onClick={() => { setEditing({ ...empty }); setShowForm(true); }}><Plus size={16} /> Add Lease</button>
        </div>
      </div>

      {showScan && <DocumentScanModal onClose={() => setShowScan(false)} onComplete={() => setLeases(getLeases())} />}

      <div className="relative mb-4">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input className="search-input pl-9" placeholder="Search by site, lessor, date, or payment..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="bg-card border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted">
              <th className="text-left p-3 font-medium text-muted-foreground">Site</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Lessor</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Start</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">End</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Payment</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Escalation</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">PDF</th>
              <th className="p-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No leases found</td></tr>
            ) : filtered.map(l => {
              const daysLeft = l.endDate ? Math.ceil((new Date(l.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : null;
              return (
                <tr key={l.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors">
                  <td className="p-3 text-foreground font-medium">{sites.find(s => s.id === l.siteId)?.name || 'N/A'}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{lessors.find(x => x.id === l.lessorId)?.fullName || 'N/A'}</td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{l.startDate || 'N/A'}</td>
                  <td className="p-3 hidden md:table-cell">
                    <span className="text-muted-foreground">{l.endDate || 'N/A'}</span>
                    {daysLeft !== null && daysLeft <= 365 && daysLeft >= 0 && (
                      <span className={`ml-2 alert-badge ${daysLeft <= 90 ? 'bg-destructive/20 text-destructive' : daysLeft <= 180 ? 'bg-warning/20 text-warning' : 'bg-info/20 text-info'}`}>
                        {daysLeft}d
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-muted-foreground hidden lg:table-cell">{l.monthlyPayment || 'N/A'}</td>
                  <td className="p-3 text-muted-foreground hidden lg:table-cell text-xs">{l.escalationType || 'None'}</td>
                  <td className="p-3 hidden lg:table-cell">
                    {l.pdfData ? (
                      <button onClick={() => downloadPdf(l)} className="inline-flex items-center gap-1 text-xs text-primary hover:underline">
                        <FileText size={13} /> {l.pdfName || 'View'}
                      </button>
                    ) : <span className="text-xs text-muted-foreground">None</span>}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1 justify-center">
                      <button onClick={() => setViewing(l)} className="p-1.5 rounded hover:bg-muted" title="View"><Eye size={15} /></button>
                      <button onClick={() => { setEditing(l); setShowForm(true); }} className="p-1.5 rounded hover:bg-muted" title="Edit"><Pencil size={15} /></button>
                      <button onClick={() => remove(l.id)} className="p-1.5 rounded hover:bg-destructive/10 text-destructive" title="Delete"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showForm && editing && (
        <ModalWrap onClose={() => { setShowForm(false); setEditing(null); }}>
          <h2 className="text-lg font-semibold text-foreground mb-4">{editing.id ? 'Edit Lease' : 'New Lease'}</h2>
          <LeaseForm lease={editing} sites={sites} lessors={lessors} onSave={save} onCancel={() => { setShowForm(false); setEditing(null); }} />
        </ModalWrap>
      )}

      {viewing && (
        <ModalWrap onClose={() => setViewing(null)}>
          <LeaseDetail lease={viewing} site={sites.find(s => s.id === viewing.siteId)} lessor={lessors.find(l => l.id === viewing.lessorId)} />
        </ModalWrap>
      )}
    </div>
  );
}

function downloadPdf(lease: Lease) {
  if (!lease.pdfData) return;
  const link = document.createElement('a');
  link.href = lease.pdfData;
  link.download = lease.pdfName || 'lease-agreement.pdf';
  link.click();
}

function ModalWrap({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={onClose}>
      <div className="bg-card rounded-lg border shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 relative" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"><X size={18} /></button>
        {children}
      </div>
    </div>
  );
}

function LeaseForm({ lease, sites, lessors, onSave, onCancel }: { lease: Lease; sites: any[]; lessors: any[]; onSave: (l: Lease) => void; onCancel: () => void }) {
  const [form, setForm] = useState(lease);
  const fileRef = useRef<HTMLInputElement>(null);
  const u = (k: keyof Lease, v: any) => setForm({ ...form, [k]: v });

  const handlePdf = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setForm(prev => ({ ...prev, pdfData: reader.result as string, pdfName: file.name }));
    };
    reader.readAsDataURL(file);
  };

  return (
    <form onSubmit={e => { e.preventDefault(); onSave(form); }} className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="form-label">Site *</label>
          <select className="form-input mt-1" value={form.siteId} onChange={e => u('siteId', e.target.value)} required>
            <option value="">-- Select --</option>
            {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label className="form-label">Lessor *</label>
          <select className="form-input mt-1" value={form.lessorId} onChange={e => u('lessorId', e.target.value)} required>
            <option value="">-- Select --</option>
            {lessors.map(l => <option key={l.id} value={l.id}>{l.fullName}</option>)}
          </select>
        </div>
        <div><label className="form-label">Start Date</label><input type="date" className="form-input mt-1" value={form.startDate} onChange={e => u('startDate', e.target.value)} /></div>
        <div><label className="form-label">Lease Term (Years)</label><input type="number" className="form-input mt-1" value={form.leaseTerm} onChange={e => u('leaseTerm', e.target.value)} placeholder="e.g. 10" /></div>
        <div><label className="form-label">End Date (auto)</label><input type="date" className="form-input mt-1 bg-muted" value={form.endDate} readOnly /></div>
        <div><label className="form-label">Monthly Payment</label><input className="form-input mt-1" value={form.monthlyPayment} onChange={e => u('monthlyPayment', e.target.value)} placeholder="e.g. K666.67" /></div>
        <div className="flex items-center gap-2 col-span-2">
          <input type="checkbox" checked={form.gstApplicable} onChange={e => u('gstApplicable', e.target.checked)} className="rounded" />
          <label className="form-label">GST Applicable</label>
        </div>
        <div><label className="form-label">Rental Rate</label><input className="form-input mt-1" value={form.rentalRate} onChange={e => u('rentalRate', e.target.value)} /></div>
        <div><label className="form-label">Installments</label><input className="form-input mt-1" value={form.installments} onChange={e => u('installments', e.target.value)} /></div>
        <div><label className="form-label">Amount Payable</label><input className="form-input mt-1" value={form.amountPayable} onChange={e => u('amountPayable', e.target.value)} /></div>
        <div><label className="form-label">Rental Increase</label><input className="form-input mt-1" value={form.rentalIncrease} onChange={e => u('rentalIncrease', e.target.value)} /></div>
        <div><label className="form-label">SG Rate</label><input className="form-input mt-1" value={form.sgRate} onChange={e => u('sgRate', e.target.value)} /></div>
        <div><label className="form-label">SG Start Date</label><input type="date" className="form-input mt-1" value={form.sgStartDate} onChange={e => u('sgStartDate', e.target.value)} /></div>
      </div>
      <div><label className="form-label">Special Remarks</label><textarea className="form-input mt-1" rows={2} value={form.specialRemarks} onChange={e => u('specialRemarks', e.target.value)} /></div>

      {/* Escalation */}
      <h3 className="text-sm font-semibold text-primary pt-2 border-t flex items-center gap-1"><TrendingUp size={14} /> CPI / Rent Escalation</h3>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="form-label">Escalation Type</label>
          <select className="form-input mt-1" value={form.escalationType || 'None'} onChange={e => u('escalationType', e.target.value)}>
            <option value="None">None</option>
            <option value="CPI">CPI</option>
            <option value="Fixed">Fixed %</option>
          </select>
        </div>
        <div><label className="form-label">Start Year</label><input type="number" className="form-input mt-1" value={form.escalationStartYear || 6} onChange={e => u('escalationStartYear', parseInt(e.target.value))} /></div>
        <div><label className="form-label">Rate (%)</label><input type="number" step="0.1" className="form-input mt-1" value={form.escalationRate || 0} onChange={e => u('escalationRate', parseFloat(e.target.value))} /></div>
        <div><label className="form-label">Interval (Years)</label><input type="number" className="form-input mt-1" value={form.escalationInterval || 1} onChange={e => u('escalationInterval', parseInt(e.target.value))} /></div>
      </div>

      {/* PDF Upload */}
      <div>
        <label className="form-label">Lease Agreement PDF</label>
        <div className="mt-1 flex items-center gap-2">
          <input ref={fileRef} type="file" accept=".pdf" onChange={handlePdf} className="hidden" />
          <button type="button" onClick={() => fileRef.current?.click()} className="btn-secondary gap-1 text-xs"><Upload size={14} /> Upload PDF</button>
          {form.pdfName && <span className="text-xs text-muted-foreground inline-flex items-center gap-1"><FileText size={13} /> {form.pdfName}</span>}
        </div>
      </div>

      <div className="flex gap-2 pt-2">
        <button type="submit" className="btn-primary">Save</button>
        <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

function LeaseDetail({ lease, site, lessor }: { lease: Lease; site?: any; lessor?: any }) {
  const escalation = calculateEscalatedRent(lease);

  const rows: [string, string][] = [
    ['Site', site?.name || 'N/A'],
    ['Lessor', lessor?.fullName || 'N/A'],
    ['Start Date', lease.startDate || 'N/A'],
    ['Lease Term', lease.leaseTerm ? `${lease.leaseTerm} years` : 'N/A'],
    ['End Date', lease.endDate || 'N/A'],
    ['Monthly Payment', lease.monthlyPayment || 'N/A'],
    ['GST Applicable', lease.gstApplicable ? 'Yes' : 'No'],
    ['Rental Rate', lease.rentalRate || 'N/A'],
    ['Installments', lease.installments || 'N/A'],
    ['Amount Payable', lease.amountPayable || 'N/A'],
    ['Rental Increase', lease.rentalIncrease || 'N/A'],
    ['SG Rate', lease.sgRate || 'N/A'],
    ['SG Start Date', lease.sgStartDate || 'N/A'],
    ['Escalation', lease.escalationType || 'None'],
    ['Special Remarks', lease.specialRemarks || 'N/A'],
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-foreground">Lease Agreement Details</h2>
      <div className="bg-muted/50 rounded-md p-3 space-y-1.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex text-sm">
            <span className="w-40 text-muted-foreground shrink-0">{k}:</span>
            <span className="text-foreground">{v}</span>
          </div>
        ))}
      </div>

      {/* Escalation Table */}
      {lease.escalationType && lease.escalationType !== 'None' && escalation.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-primary mb-2 flex items-center gap-1"><TrendingUp size={14} /> Projected Rent Escalation</h3>
          <div className="bg-muted/50 rounded-md overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b">
                  <th className="p-2 text-left text-muted-foreground">Year</th>
                  <th className="p-2 text-left text-muted-foreground">Monthly Rent</th>
                </tr>
              </thead>
              <tbody>
                {escalation.map(e => (
                  <tr key={e.year} className="border-b last:border-0">
                    <td className="p-2 text-foreground">Year {e.year}</td>
                    <td className="p-2 text-foreground font-medium">K{e.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {lease.pdfData && (
        <div>
          <button onClick={() => downloadPdf(lease)} className="btn-secondary gap-1 text-sm">
            <Download size={14} /> View PDF: {lease.pdfName || 'lease-agreement.pdf'}
          </button>
        </div>
      )}
    </div>
  );
}
