import { useState, useMemo } from 'react';
import { getPayments, addPayment, updatePayment, deletePayment, getSites, getLessors, getLeases, exportToCSV } from '@/lib/store';
import { Payment } from '@/lib/types';
import { Plus, Pencil, Trash2, X, Search, Download, CheckCircle, Clock, AlertTriangle } from 'lucide-react';

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export default function Payments() {
  const [payments, setPayments] = useState(getPayments);
  const [editing, setEditing] = useState<Payment | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const sites = getSites();
  const lessors = getLessors();
  const leases = getLeases();

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return payments;
    return payments.filter(p => {
      const site = sites.find(s => s.id === p.siteId);
      const lessor = lessors.find(l => l.id === p.lessorId);
      return (site?.name || '').toLowerCase().includes(q) ||
        (lessor?.fullName || '').toLowerCase().includes(q) ||
        p.status.toLowerCase().includes(q) ||
        p.month.toLowerCase().includes(q) ||
        p.amount.toLowerCase().includes(q);
    });
  }, [payments, search, sites, lessors]);

  const save = (p: Payment) => {
    if (p.id) { updatePayment(p); } else { p.id = crypto.randomUUID(); addPayment(p); }
    setPayments(getPayments());
    setEditing(null);
    setShowForm(false);
  };

  const remove = (id: string) => { if (confirm('Delete this payment?')) { deletePayment(id); setPayments(getPayments()); } };

  const handleExport = () => {
    exportToCSV(payments.map(p => {
      const site = sites.find(s => s.id === p.siteId);
      const lessor = lessors.find(l => l.id === p.lessorId);
      return {
        Site: site?.name || '', Lessor: lessor?.fullName || '',
        Month: p.month, Year: p.year, Amount: p.amount,
        DueDate: p.dueDate, PaidDate: p.paidDate || '', Status: p.status,
      };
    }), 'payments.csv');
  };

  const empty: Payment = { id: '', leaseId: '', siteId: '', lessorId: '', amount: '', dueDate: '', status: 'Pending', month: '', year: new Date().getFullYear().toString() };

  const paid = payments.filter(p => p.status === 'Paid').length;
  const pending = payments.filter(p => p.status === 'Pending').length;
  const overdue = payments.filter(p => p.status === 'Overdue').length;

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="page-title">Payments</h1>
        <div className="flex gap-2">
          <button className="btn-secondary gap-2" onClick={handleExport}><Download size={16} /> Export CSV</button>
          <button className="btn-primary gap-2" onClick={() => { setEditing({ ...empty }); setShowForm(true); }}><Plus size={16} /> Add Payment</button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="stat-card-primary flex items-center gap-3">
          <CheckCircle size={20} className="text-success" />
          <div><p className="text-xs text-muted-foreground">Paid</p><p className="text-xl font-bold text-foreground">{paid}</p></div>
        </div>
        <div className="stat-card-primary flex items-center gap-3">
          <Clock size={20} className="text-warning" />
          <div><p className="text-xs text-muted-foreground">Pending</p><p className="text-xl font-bold text-foreground">{pending}</p></div>
        </div>
        <div className="stat-card-primary flex items-center gap-3">
          <AlertTriangle size={20} className="text-destructive" />
          <div><p className="text-xs text-muted-foreground">Overdue</p><p className="text-xl font-bold text-foreground">{overdue}</p></div>
        </div>
      </div>

      <div className="relative mb-4">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input className="search-input pl-9" placeholder="Search by site, lessor, status, month, or amount..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="bg-card border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted">
              <th className="text-left p-3 font-medium text-muted-foreground">Site</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Lessor</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Month</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden md:table-cell">Amount</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Due Date</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Paid Date</th>
              <th className="text-left p-3 font-medium text-muted-foreground">Status</th>
              <th className="p-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No payments found</td></tr>
            ) : filtered.map(p => (
              <tr key={p.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors">
                <td className="p-3 text-foreground font-medium">{sites.find(s => s.id === p.siteId)?.name || 'N/A'}</td>
                <td className="p-3 text-muted-foreground hidden md:table-cell">{lessors.find(l => l.id === p.lessorId)?.fullName || 'N/A'}</td>
                <td className="p-3 text-muted-foreground">{p.month} {p.year}</td>
                <td className="p-3 text-muted-foreground hidden md:table-cell">{p.amount}</td>
                <td className="p-3 text-muted-foreground hidden lg:table-cell">{p.dueDate}</td>
                <td className="p-3 text-muted-foreground hidden lg:table-cell">{p.paidDate || '-'}</td>
                <td className="p-3">
                  <span className={`alert-badge ${
                    p.status === 'Paid' ? 'bg-success/20 text-success' :
                    p.status === 'Overdue' ? 'bg-destructive/20 text-destructive' :
                    'bg-warning/20 text-warning'
                  }`}>{p.status}</span>
                </td>
                <td className="p-3">
                  <div className="flex gap-1 justify-center">
                    <button onClick={() => { setEditing(p); setShowForm(true); }} className="p-1.5 rounded hover:bg-muted" title="Edit"><Pencil size={15} /></button>
                    <button onClick={() => remove(p.id)} className="p-1.5 rounded hover:bg-destructive/10 text-destructive" title="Delete"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && editing && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={() => { setShowForm(false); setEditing(null); }}>
          <div className="bg-card rounded-lg border shadow-lg w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 relative" onClick={e => e.stopPropagation()}>
            <button onClick={() => { setShowForm(false); setEditing(null); }} className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"><X size={18} /></button>
            <h2 className="text-lg font-semibold text-foreground mb-4">{editing.id ? 'Edit Payment' : 'New Payment'}</h2>
            <PaymentForm payment={editing} leases={leases} sites={sites} lessors={lessors} onSave={save} onCancel={() => { setShowForm(false); setEditing(null); }} />
          </div>
        </div>
      )}
    </div>
  );
}

function PaymentForm({ payment, leases, sites, lessors, onSave, onCancel }: {
  payment: Payment; leases: any[]; sites: any[]; lessors: any[];
  onSave: (p: Payment) => void; onCancel: () => void;
}) {
  const [form, setForm] = useState(payment);
  const u = (k: keyof Payment, v: any) => setForm({ ...form, [k]: v });

  const handleLeaseChange = (leaseId: string) => {
    const lease = leases.find((l: any) => l.id === leaseId);
    if (lease) {
      setForm(prev => ({ ...prev, leaseId, siteId: lease.siteId, lessorId: lease.lessorId, amount: lease.monthlyPayment }));
    } else {
      u('leaseId', leaseId);
    }
  };

  return (
    <form onSubmit={e => { e.preventDefault(); onSave(form); }} className="space-y-3">
      <div>
        <label className="form-label">Lease *</label>
        <select className="form-input mt-1" value={form.leaseId} onChange={e => handleLeaseChange(e.target.value)} required>
          <option value="">-- Select Lease --</option>
          {leases.map((l: any) => {
            const site = sites.find((s: any) => s.id === l.siteId);
            return <option key={l.id} value={l.id}>{site?.name || 'Unknown'} - {l.monthlyPayment}</option>;
          })}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="form-label">Month</label>
          <select className="form-input mt-1" value={form.month} onChange={e => u('month', e.target.value)}>
            <option value="">-- Select --</option>
            {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>
        <div><label className="form-label">Year</label><input className="form-input mt-1" value={form.year} onChange={e => u('year', e.target.value)} placeholder="2025" /></div>
        <div><label className="form-label">Amount</label><input className="form-input mt-1" value={form.amount} onChange={e => u('amount', e.target.value)} placeholder="K666.67" /></div>
        <div><label className="form-label">Due Date</label><input type="date" className="form-input mt-1" value={form.dueDate} onChange={e => u('dueDate', e.target.value)} /></div>
        <div><label className="form-label">Paid Date</label><input type="date" className="form-input mt-1" value={form.paidDate || ''} onChange={e => u('paidDate', e.target.value)} /></div>
        <div>
          <label className="form-label">Status</label>
          <select className="form-input mt-1" value={form.status} onChange={e => u('status', e.target.value as any)}>
            <option>Pending</option><option>Paid</option><option>Overdue</option>
          </select>
        </div>
      </div>
      <div className="flex gap-2 pt-2">
        <button type="submit" className="btn-primary">Save</button>
        <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}
