import { useState, useMemo } from 'react';
import { getSites, addSite, updateSite, deleteSite, getLessors, exportToCSV } from '@/lib/store';
import { Site } from '@/lib/types';
import SiteMap from '@/components/SiteMap';
import SiteFormModal from '@/components/sites/SiteFormModal';
import SiteDetailModal from '@/components/sites/SiteDetailModal';
import DocumentScanModal from '@/components/DocumentScanModal';
import ReportIssueModal from '@/components/issues/ReportIssueModal';
import { Plus, Pencil, Trash2, Eye, ArrowUpDown, Search, Download, MapPin, Radio, AlertCircle, Filter, ScanLine } from 'lucide-react';

const empty: Site = { id: '', name: '', code: 'VP', province: '', address: '', latitude: '', longitude: '', landType: '', lessorId: '', status: 'Pending', buildStatus: 'N/A', associatedUser: '', associatedEmail: '' };

type SortKey = 'name' | 'code' | 'province' | 'status';

export default function Sites() {
  const [sites, setSites] = useState(getSites);
  const [editing, setEditing] = useState<Site | null>(null);
  const [viewing, setViewing] = useState<Site | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [showScan, setShowScan] = useState(false);
  const [reportIssueSite, setReportIssueSite] = useState<Site | null>(null);
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortAsc, setSortAsc] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [provinceFilter, setProvinceFilter] = useState<string>('All');
  const [showMap, setShowMap] = useState(true);
  const lessors = getLessors();

  const provinces = useMemo(() => ['All', ...Array.from(new Set(sites.map(s => s.province).filter(Boolean)))], [sites]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return sites.filter(s => {
      if (statusFilter !== 'All' && s.status !== statusFilter) return false;
      if (provinceFilter !== 'All' && s.province !== provinceFilter) return false;
      if (!q) return true;
      return (
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.province.toLowerCase().includes(q) ||
        (lessors.find(l => l.id === s.lessorId)?.fullName || '').toLowerCase().includes(q)
      );
    });
  }, [sites, search, statusFilter, provinceFilter, lessors]);

  const sorted = useMemo(() => {
    const copy = [...filtered];
    copy.sort((a, b) => {
      const va = a[sortKey].toLowerCase();
      const vb = b[sortKey].toLowerCase();
      return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    });
    return copy;
  }, [filtered, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(true); }
  };

  const save = (s: Site) => {
    if (s.id) { updateSite(s); } else { s.id = crypto.randomUUID(); addSite(s); }
    setSites(getSites());
    setEditing(null);
    setShowForm(false);
  };

  const remove = (id: string) => { if (confirm('Delete this site?')) { deleteSite(id); setSites(getSites()); } };

  const handleExport = () => {
    exportToCSV(sites.map(s => ({
      Name: s.name, Code: s.code, Province: s.province, Address: s.address,
      Latitude: s.latitude, Longitude: s.longitude, LandType: s.landType,
      Status: s.status, BuildStatus: s.buildStatus,
      Lessor: lessors.find(l => l.id === s.lessorId)?.fullName || '',
      User: s.associatedUser, Email: s.associatedEmail
    })), 'sites.csv');
  };

  const stats = useMemo(() => ({
    total: sites.length,
    active: sites.filter(s => s.status === 'Active').length,
    pending: sites.filter(s => s.status === 'Pending').length,
    inactive: sites.filter(s => s.status === 'Inactive').length,
  }), [sites]);

  const SortHeader = ({ label, k, className = '' }: { label: string; k: SortKey; className?: string }) => (
    <th className={`text-left p-3 font-medium text-muted-foreground cursor-pointer select-none hover:text-foreground transition-colors ${className}`} onClick={() => toggleSort(k)}>
      <span className="inline-flex items-center gap-1">{label}<ArrowUpDown size={13} className={sortKey === k ? 'text-primary' : 'opacity-40'} /></span>
    </th>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Sites</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage and monitor all tower sites across regions</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-primary gap-2" onClick={() => setShowScan(true)}><ScanLine size={16} /> Scan Document</button>
          <button className="btn-secondary gap-2" onClick={handleExport}><Download size={16} /> Export</button>
          <button className="btn-secondary gap-2" onClick={() => { setEditing({ ...empty }); setShowForm(true); }}><Plus size={16} /> Add Site</button>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={<Radio size={20} />} label="Total Sites" value={stats.total} color="primary" />
        <StatCard icon={<MapPin size={20} />} label="Active" value={stats.active} color="success" />
        <StatCard icon={<AlertCircle size={20} />} label="Pending" value={stats.pending} color="warning" />
        <StatCard icon={<Radio size={20} />} label="Inactive" value={stats.inactive} color="muted" />
      </div>

      {/* Filters Row */}
      <div className="rounded-lg border bg-card p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-medium text-foreground">
          <Filter size={15} /> Filters
        </div>
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input className="form-input pl-9" placeholder="Search sites by name, code, or lessor..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="form-input md:w-40" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Pending">Pending</option>
            <option value="Inactive">Inactive</option>
          </select>
          <select className="form-input md:w-44" value={provinceFilter} onChange={e => setProvinceFilter(e.target.value)}>
            {provinces.map(p => <option key={p} value={p}>{p === 'All' ? 'All Provinces' : p}</option>)}
          </select>
        </div>
        {(statusFilter !== 'All' || provinceFilter !== 'All' || search) && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-muted-foreground">Active filters:</span>
            {statusFilter !== 'All' && <FilterChip label={`Status: ${statusFilter}`} onClear={() => setStatusFilter('All')} />}
            {provinceFilter !== 'All' && <FilterChip label={`Province: ${provinceFilter}`} onClear={() => setProvinceFilter('All')} />}
            {search && <FilterChip label={`Search: "${search}"`} onClear={() => setSearch('')} />}
            <button onClick={() => { setStatusFilter('All'); setProvinceFilter('All'); setSearch(''); }} className="text-xs text-primary hover:underline ml-1">Clear all</button>
          </div>
        )}
      </div>

      {/* Map Section */}
      <div className="rounded-lg border bg-card overflow-hidden">
        <button onClick={() => setShowMap(!showMap)} className="w-full flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <MapPin size={16} className="text-primary" /> Site Locations
            <span className="text-xs font-normal text-muted-foreground">({filtered.length} sites shown)</span>
          </div>
          <span className="text-xs text-muted-foreground">{showMap ? 'Hide' : 'Show'} Map</span>
        </button>
        {showMap && (
          <div className="border-t">
            <SiteMap sites={filtered} onReportIssue={site => setReportIssueSite(site)} />
          </div>
        )}
      </div>

      {/* Table */}
      <div className="rounded-lg border bg-card overflow-hidden">
        <div className="p-4 border-b flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">{filtered.length} site{filtered.length !== 1 ? 's' : ''} found</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/50">
                <SortHeader label="Name" k="name" />
                <SortHeader label="Code" k="code" />
                <SortHeader label="Province" k="province" className="hidden md:table-cell" />
                <SortHeader label="Status" k="status" className="hidden sm:table-cell" />
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Build Status</th>
                <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Lessor</th>
                <th className="p-3 font-medium text-muted-foreground text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.length === 0 ? (
                <tr><td colSpan={7} className="p-12 text-center text-muted-foreground">
                  <div className="flex flex-col items-center gap-2">
                    <Radio size={32} className="opacity-30" />
                    <span>No sites match your filters</span>
                  </div>
                </td></tr>
              ) : sorted.map(s => (
                <tr key={s.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="p-3">
                    <div className="font-medium text-foreground">{s.name}</div>
                    <div className="text-xs text-muted-foreground md:hidden">{s.province}</div>
                  </td>
                  <td className="p-3 font-mono text-xs">
                    <span className="font-semibold text-primary">VP</span>
                    <span className="text-muted-foreground">{s.code.replace(/^VP/i, '')}</span>
                  </td>
                  <td className="p-3 text-muted-foreground hidden md:table-cell">{s.province}</td>
                  <td className="p-3 hidden sm:table-cell">
                    <StatusBadge status={s.status} />
                  </td>
                  <td className="p-3 hidden lg:table-cell">
                    <span className="text-xs text-muted-foreground">{s.buildStatus}</span>
                  </td>
                  <td className="p-3 text-muted-foreground hidden lg:table-cell text-sm">{lessors.find(l => l.id === s.lessorId)?.fullName || '—'}</td>
                  <td className="p-3">
                    <div className="flex gap-1 justify-end">
                      <button onClick={() => setViewing(s)} className="p-1.5 rounded-md hover:bg-muted transition-colors" title="View"><Eye size={15} className="text-muted-foreground" /></button>
                      <button onClick={() => { setEditing(s); setShowForm(true); }} className="p-1.5 rounded-md hover:bg-muted transition-colors" title="Edit"><Pencil size={15} className="text-muted-foreground" /></button>
                      <button onClick={() => remove(s.id)} className="p-1.5 rounded-md hover:bg-destructive/10 transition-colors" title="Delete"><Trash2 size={15} className="text-destructive" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && editing && (
        <SiteFormModal site={editing} lessors={lessors} onSave={save} onClose={() => { setShowForm(false); setEditing(null); }} />
      )}
      {showScan && <DocumentScanModal onClose={() => setShowScan(false)} onComplete={() => setSites(getSites())} />}
      {viewing && (
        <SiteDetailModal site={viewing} lessor={lessors.find(l => l.id === viewing.lessorId)} onClose={() => setViewing(null)} />
      )}
      {reportIssueSite && (
        <ReportIssueModal site={reportIssueSite} onClose={() => setReportIssueSite(null)} />
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    primary: 'bg-primary/10 text-primary',
    success: 'bg-success/10 text-success',
    warning: 'bg-warning/10 text-warning',
    muted: 'bg-muted text-muted-foreground',
  };
  return (
    <div className="rounded-lg border bg-card p-4 flex items-center gap-3">
      <div className={`rounded-lg p-2.5 ${colorMap[color]}`}>{icon}</div>
      <div>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    Active: 'bg-success/15 text-success border-success/20',
    Pending: 'bg-warning/15 text-warning border-warning/20',
    Inactive: 'bg-muted text-muted-foreground border-border',
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${styles[status] || styles.Inactive}`}>{status}</span>;
}

function FilterChip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 text-primary px-2.5 py-0.5 text-xs font-medium">
      {label}
      <button onClick={onClear} className="hover:text-primary/70 ml-0.5">×</button>
    </span>
  );
}
