import { useState, useEffect } from 'react';
import { Settings, Plus, Trash2, Mail, Building2, Tag, Link2 } from 'lucide-react';
import {
  fetchCategories, addCategory, deleteCategory,
  fetchDepartments, addDepartment, deleteDepartment,
  fetchDepartmentEmails, addDepartmentEmail, deleteDepartmentEmail,
  fetchCategoryDepartmentMap, setCategoryDepartment,
  IssueCategory, Department, DepartmentEmail, CategoryDepartmentMap,
} from '@/lib/issues';
import { toast } from 'sonner';

export default function AdminSettings() {
  const [categories, setCategories] = useState<IssueCategory[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [emails, setEmails] = useState<DepartmentEmail[]>([]);
  const [mappings, setMappings] = useState<CategoryDepartmentMap[]>([]);
  const [newCategory, setNewCategory] = useState('');
  const [newDepartment, setNewDepartment] = useState('');
  const [newEmail, setNewEmail] = useState({ departmentId: '', email: '', isBoss: false, label: '' });
  const [activeTab, setActiveTab] = useState<'categories' | 'departments' | 'emails' | 'mappings'>('categories');

  const load = async () => {
    try {
      const [cats, deps, ems, maps] = await Promise.all([
        fetchCategories(), fetchDepartments(), fetchDepartmentEmails(), fetchCategoryDepartmentMap(),
      ]);
      setCategories(cats); setDepartments(deps); setEmails(ems); setMappings(maps);
    } catch (err: any) { toast.error(err.message); }
  };

  useEffect(() => { load(); }, []);

  const handleAddCategory = async () => {
    if (!newCategory.trim()) return;
    try { await addCategory(newCategory.trim()); setNewCategory(''); await load(); toast.success('Category added'); }
    catch (err: any) { toast.error(err.message); }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Delete this category?')) return;
    try { await deleteCategory(id); await load(); toast.success('Category deleted'); }
    catch (err: any) { toast.error(err.message); }
  };

  const handleAddDepartment = async () => {
    if (!newDepartment.trim()) return;
    try { await addDepartment(newDepartment.trim()); setNewDepartment(''); await load(); toast.success('Department added'); }
    catch (err: any) { toast.error(err.message); }
  };

  const handleDeleteDepartment = async (id: string) => {
    if (!confirm('Delete this department?')) return;
    try { await deleteDepartment(id); await load(); toast.success('Department deleted'); }
    catch (err: any) { toast.error(err.message); }
  };

  const handleAddEmail = async () => {
    if (!newEmail.departmentId || !newEmail.email.trim()) return;
    try {
      await addDepartmentEmail(newEmail.departmentId, newEmail.email.trim(), newEmail.isBoss, newEmail.label || undefined);
      setNewEmail({ departmentId: '', email: '', isBoss: false, label: '' });
      await load(); toast.success('Email added');
    } catch (err: any) { toast.error(err.message); }
  };

  const handleDeleteEmail = async (id: string) => {
    try { await deleteDepartmentEmail(id); await load(); toast.success('Email removed'); }
    catch (err: any) { toast.error(err.message); }
  };

  const handleSetMapping = async (categoryId: string, departmentId: string) => {
    try { await setCategoryDepartment(categoryId, departmentId); await load(); toast.success('Mapping updated'); }
    catch (err: any) { toast.error(err.message); }
  };

  const tabs = [
    { key: 'categories' as const, label: 'Categories', icon: Tag },
    { key: 'departments' as const, label: 'Departments', icon: Building2 },
    { key: 'emails' as const, label: 'Email Recipients', icon: Mail },
    { key: 'mappings' as const, label: 'Category → Dept', icon: Link2 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2"><Settings size={24} /> Admin Settings</h1>
        <p className="text-sm text-muted-foreground mt-0.5">Manage issue categories, departments, and email routing</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
              activeTab === t.key ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}>
            <t.icon size={16} /> {t.label}
          </button>
        ))}
      </div>

      {/* Categories Tab */}
      {activeTab === 'categories' && (
        <div className="rounded-lg border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Issue Categories</h3>
          <div className="flex gap-2">
            <input className="form-input flex-1" placeholder="New category name..." value={newCategory} onChange={e => setNewCategory(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddCategory()} />
            <button className="btn-primary gap-1" onClick={handleAddCategory}><Plus size={16} /> Add</button>
          </div>
          <div className="space-y-1">
            {categories.map(c => (
              <div key={c.id} className="flex items-center justify-between px-3 py-2 rounded-md hover:bg-muted/50 transition-colors">
                <span className="text-sm text-foreground">{c.name}</span>
                <button onClick={() => handleDeleteCategory(c.id)} className="p-1 rounded hover:bg-destructive/10 transition-colors">
                  <Trash2 size={14} className="text-destructive" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Departments Tab */}
      {activeTab === 'departments' && (
        <div className="rounded-lg border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Departments</h3>
          <div className="flex gap-2">
            <input className="form-input flex-1" placeholder="New department name..." value={newDepartment} onChange={e => setNewDepartment(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddDepartment()} />
            <button className="btn-primary gap-1" onClick={handleAddDepartment}><Plus size={16} /> Add</button>
          </div>
          <div className="space-y-1">
            {departments.map(d => (
              <div key={d.id} className="flex items-center justify-between px-3 py-2 rounded-md hover:bg-muted/50 transition-colors">
                <span className="text-sm text-foreground">{d.name}</span>
                <button onClick={() => handleDeleteDepartment(d.id)} className="p-1 rounded hover:bg-destructive/10 transition-colors">
                  <Trash2 size={14} className="text-destructive" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Emails Tab */}
      {activeTab === 'emails' && (
        <div className="rounded-lg border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Email Recipients per Department</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
            <select className="form-input" value={newEmail.departmentId} onChange={e => setNewEmail({ ...newEmail, departmentId: e.target.value })}>
              <option value="">Select department...</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            <input className="form-input" placeholder="Email address" value={newEmail.email} onChange={e => setNewEmail({ ...newEmail, email: e.target.value })} />
            <input className="form-input" placeholder="Label (optional)" value={newEmail.label} onChange={e => setNewEmail({ ...newEmail, label: e.target.value })} />
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 text-sm text-foreground cursor-pointer">
                <input type="checkbox" checked={newEmail.isBoss} onChange={e => setNewEmail({ ...newEmail, isBoss: e.target.checked })} className="rounded" />
                Boss / Primary
              </label>
              <button className="btn-primary gap-1 ml-auto" onClick={handleAddEmail}><Plus size={16} /></button>
            </div>
          </div>

          {departments.map(dept => {
            const deptEmails = emails.filter(e => e.department_id === dept.id);
            if (deptEmails.length === 0) return null;
            return (
              <div key={dept.id} className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground uppercase">{dept.name}</p>
                {deptEmails.map(em => (
                  <div key={em.id} className="flex items-center justify-between px-3 py-2 rounded-md bg-muted/30">
                    <div className="flex items-center gap-2">
                      <Mail size={14} className="text-muted-foreground" />
                      <span className="text-sm text-foreground">{em.email}</span>
                      {em.is_boss && <span className="text-[10px] font-semibold bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">BOSS</span>}
                      {em.label && <span className="text-xs text-muted-foreground">({em.label})</span>}
                    </div>
                    <button onClick={() => handleDeleteEmail(em.id)} className="p-1 rounded hover:bg-destructive/10 transition-colors">
                      <Trash2 size={14} className="text-destructive" />
                    </button>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}

      {/* Mappings Tab */}
      {activeTab === 'mappings' && (
        <div className="rounded-lg border bg-card p-5 space-y-4">
          <h3 className="text-sm font-semibold text-foreground">Category → Department Routing</h3>
          <p className="text-xs text-muted-foreground">Assign which department is responsible for each issue category. Emails will be sent to the department's contacts when issues are reported.</p>
          <div className="space-y-2">
            {categories.map(cat => {
              const mapping = mappings.find(m => m.category_id === cat.id);
              return (
                <div key={cat.id} className="flex items-center gap-3 px-3 py-2.5 rounded-md bg-muted/30">
                  <span className="text-sm font-medium text-foreground min-w-[160px]">{cat.name}</span>
                  <span className="text-muted-foreground">→</span>
                  <select className="form-input flex-1" value={mapping?.department_id || ''} onChange={e => e.target.value && handleSetMapping(cat.id, e.target.value)}>
                    <option value="">Not assigned</option>
                    {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
