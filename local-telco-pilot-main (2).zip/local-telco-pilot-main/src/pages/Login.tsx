import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login } from '@/lib/store';
import logo from '@/assets/logo.png';
import towerBg from '@/assets/tower-bg.jpg';
import { Radio, Shield } from 'lucide-react';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(username, password)) { navigate('/'); } else { setError('Invalid credentials'); }
  };

  return (
    <div className="min-h-screen flex">
      {/* Background Image Section */}
      <div className="hidden lg:flex lg:w-1/2 xl:w-3/5 relative overflow-hidden">
        <img
          src={towerBg}
          alt="Cell Tower"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50" />

        {/* Content Overlay */}
        <div className="relative z-10 flex flex-col justify-end p-12 xl:p-16">
          <div className="mb-8">
            <div className="inline-flex items-center gap-3 bg-background/90 backdrop-blur-sm rounded-full px-5 py-2.5 mb-6 shadow-lg">
              <Radio className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-foreground">Vodafone Network Operations</span>
            </div>
            <h2 className="text-4xl xl:text-5xl font-bold text-foreground mb-4 leading-tight">
              Managing<br />Network Sites<br />Efficiently
            </h2>
            <p className="text-muted-foreground text-lg max-w-md">
              Secure access to our comprehensive site management platform. Monitor, manage, and maintain network infrastructure.
            </p>
          </div>

          {/* Stats */}
          <div className="flex gap-8">
            <div>
              <p className="text-3xl font-bold text-primary">500+</p>
              <p className="text-sm text-muted-foreground">Active Sites</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-primary">99.9%</p>
              <p className="text-sm text-muted-foreground">Uptime</p>
            </div>
            <div>
              <p className="text-3xl font-bold text-primary">24/7</p>
              <p className="text-sm text-muted-foreground">Support</p>
            </div>
          </div>
        </div>
      </div>

      {/* Login Form Section */}
      <div className="flex-1 flex items-center justify-center bg-background p-6 relative">
        {/* Mobile Background */}
        <div className="absolute inset-0 lg:hidden">
          <img
            src={towerBg}
            alt="Cell Tower"
            className="absolute inset-0 w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-background/95" />
        </div>

        <div className="w-full max-w-sm relative z-10">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-primary/70 shadow-lg shadow-primary/25 mb-4">
              <img src={logo} alt="Vodafone" className="w-10 h-10 object-contain" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">Vodafone Site Manager</h1>
            <p className="text-muted-foreground text-sm mt-1">Secure sign in to your account</p>
          </div>

          {/* Login Card */}
          <form onSubmit={handleSubmit} className="bg-card/95 backdrop-blur-sm rounded-xl border p-6 shadow-xl space-y-5">
            {error && (
              <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 rounded-lg px-4 py-3">
                <Shield className="w-4 h-4" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Username</label>
              <input
                className="form-input"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Password</label>
              <input
                className="form-input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
            </div>

            <button type="submit" className="btn-primary w-full py-2.5 shadow-lg shadow-primary/20">
              Sign In
            </button>

            <p className="text-xs text-muted-foreground text-center pt-2">
              Default credentials: admin / admin123
            </p>
          </form>

          {/* Footer */}
          <p className="text-xs text-muted-foreground text-center mt-8">
            © {new Date().getFullYear()} Vodafone Ghana. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}
