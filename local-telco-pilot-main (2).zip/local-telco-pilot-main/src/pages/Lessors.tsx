import { useState, useMemo } from 'react';
import { getLessors, addLessor, updateLessor, deleteLessor, exportToCSV } from '@/lib/store';
import { Lessor } from '@/lib/types';
import DocumentScanModal from '@/components/DocumentScanModal';
import { Plus, Pencil, Trash2, Eye, X, ArrowUpDown, Copy, Check, Search, Download, ScanLine } from 'lucide-react';

const empty: Lessor = { id: '', fullName: '', isGuardian: false, address: '', phone: '', mobile: '', fax: '', tinNumber: '', bankName: '', bankBranch: '', bankAccount: '', bankAccountName: '', guardianName: '', guardianAccountName: '', guardianAccountNumber: '', guardianBankName: '', guardianBranch: '' };

type SortKey = 'fullName' | 'phone' | 'tinNumber';

export default function Lessors() {
  const [lessors, setLessors] = useState(getLessors);
  const [editing, setEditing] = useState<Lessor | null>(null);
  const [viewing, setViewing] = useState<Lessor | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [showScan, setShowScan] = useState(false);
  const [sortKey, setSortKey] = useState<SortKey>('fullName');
  const [sortAsc, setSortAsc] = useState(true);
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    if (!q) return lessors;
    return lessors.filter(l =>
      l.fullName.toLowerCase().includes(q) ||
      l.address.toLowerCase().includes(q) ||
      (l.tinNumber || '').toLowerCase().includes(q) ||
      l.phone.toLowerCase().includes(q)
    );
  }, [lessors, search]);

  const sorted = useMemo(() => {
    const copy = [...filtered];
    copy.sort((a, b) => {
      const va = (a[sortKey] || '').toString().toLowerCase();
      const vb = (b[sortKey] || '').toString().toLowerCase();
      return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
    });
    return copy;
  }, [filtered, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortAsc(!sortAsc);
    else { setSortKey(key); setSortAsc(true); }
  };

  const save = (l: Lessor) => {
    if (l.id) { updateLessor(l); } else { l.id = crypto.randomUUID(); addLessor(l); }
    setLessors(getLessors());
    setEditing(null);
    setShowForm(false);
  };

  const remove = (id: string) => { if (confirm('Delete this lessor?')) { deleteLessor(id); setLessors(getLessors()); } };

  const handleExport = () => {
    exportToCSV(lessors.map(l => ({
      FullName: l.fullName, Address: l.address, Phone: l.phone, Mobile: l.mobile,
      Fax: l.fax, TIN: l.tinNumber, BankName: l.bankName || '', Branch: l.bankBranch || '',
      Account: l.bankAccount || '', Guardian: l.isGuardian ? 'Yes' : 'No',
    })), 'lessors.csv');
  };

  const SortHeader = ({ label, k, className = '' }: { label: string; k: SortKey; className?: string }) => (
    <th className={`text-left p-3 font-medium text-muted-foreground cursor-pointer select-none hover:text-foreground ${className}`} onClick={() => toggleSort(k)}>
      <span className="inline-flex items-center gap-1">{label}<ArrowUpDown size={13} className={sortKey === k ? 'text-primary' : 'opacity-40'} /></span>
    </th>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="page-title">Lessors</h1>
        <div className="flex gap-2">
          <button className="btn-primary gap-2" onClick={() => setShowScan(true)}><ScanLine size={16} /> Scan Document</button>
          <button className="btn-secondary gap-2" onClick={handleExport}><Download size={16} /> Export CSV</button>
          <button className="btn-secondary gap-2" onClick={() => { setEditing({ ...empty }); setShowForm(true); }}><Plus size={16} /> Create New Lessor</button>
        </div>
      </div>

      {showScan && <DocumentScanModal onClose={() => setShowScan(false)} onComplete={() => setLessors(getLessors())} />}

      <div className="relative mb-4">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input className="search-input pl-9" placeholder="Search by name, address, TIN, or phone..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="bg-card border rounded-lg overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted">
              <SortHeader label="Full Name" k="fullName" />
              <SortHeader label="Phone" k="phone" className="hidden md:table-cell" />
              <SortHeader label="TIN" k="tinNumber" className="hidden lg:table-cell" />
              <th className="text-left p-3 font-medium text-muted-foreground hidden lg:table-cell">Guardian</th>
              <th className="text-left p-3 font-medium text-muted-foreground hidden xl:table-cell">Bank Details</th>
              <th className="p-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sorted.length === 0 ? (
              <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No lessors found</td></tr>
            ) : sorted.map(l => (
              <tr key={l.id} className="border-b last:border-0 hover:bg-muted/50 transition-colors">
                <td className="p-3 text-foreground font-medium">{l.fullName}</td>
                <td className="p-3 text-muted-foreground hidden md:table-cell">{l.phone}</td>
                <td className="p-3 text-muted-foreground hidden lg:table-cell">{l.tinNumber || 'N/A'}</td>
                <td className="p-3 hidden lg:table-cell">{l.isGuardian ? <span className="alert-badge bg-primary/20 text-primary">Yes</span> : 'No'}</td>
                <td className="p-3 hidden xl:table-cell">
                  {l.bankName ? (
                    <div className="flex flex-col gap-0.5">
                      <CopyField label="Bank" value={l.bankName} />
                      <CopyField label="Branch" value={l.bankBranch || ''} />
                      <CopyField label="Acct" value={l.bankAccount || ''} />
                    </div>
                  ) : <span className="text-muted-foreground text-xs">N/A</span>}
                </td>
                <td className="p-3">
                  <div className="flex gap-1 justify-center">
                    <button onClick={() => setViewing(l)} className="p-1.5 rounded hover:bg-muted" title="View"><Eye size={15} /></button>
                    <button onClick={() => { setEditing(l); setShowForm(true); }} className="p-1.5 rounded hover:bg-muted" title="Edit"><Pencil size={15} /></button>
                    <button onClick={() => remove(l.id)} className="p-1.5 rounded hover:bg-destructive/10 text-destructive" title="Delete"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && editing && (
        <ModalWrap onClose={() => { setShowForm(false); setEditing(null); }}>
          <h2 className="text-lg font-semibold text-foreground mb-4">{editing.id ? 'Edit Lessor' : 'Create New Lessor'}</h2>
          <LessorForm lessor={editing} onSave={save} onCancel={() => { setShowForm(false); setEditing(null); }} />
        </ModalWrap>
      )}

      {viewing && (
        <ModalWrap onClose={() => setViewing(null)}>
          <LessorDetail lessor={viewing} />
        </ModalWrap>
      )}
    </div>
  );
}

function ModalWrap({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={onClose}>
      <div className="bg-card rounded-lg border shadow-lg w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 relative" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"><X size={18} /></button>
        {children}
      </div>
    </div>
  );
}

function CopyField({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false);
  if (!value) return null;
  const copy = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      <span className="font-medium">{label}:</span> {value}
      <button onClick={copy} className="p-0.5 rounded hover:bg-muted" title={`Copy ${label}`}>
        {copied ? <Check size={11} className="text-success" /> : <Copy size={11} />}
      </button>
    </span>
  );
}

function LessorForm({ lessor, onSave, onCancel }: { lessor: Lessor; onSave: (l: Lessor) => void; onCancel: () => void }) {
  const [form, setForm] = useState(lessor);
  const u = (k: keyof Lessor, v: any) => setForm({ ...form, [k]: v });

  return (
    <form onSubmit={e => { e.preventDefault(); onSave(form); }} className="space-y-3">
      <div><label className="form-label">Full Name *</label><input className="form-input mt-1" value={form.fullName} onChange={e => u('fullName', e.target.value)} required placeholder="Full name" /></div>
      <div className="flex items-center gap-2">
        <input type="checkbox" checked={form.isGuardian} onChange={e => u('isGuardian', e.target.checked)} className="rounded" />
        <label className="form-label">Is Guardian</label>
      </div>
      <div><label className="form-label">Address *</label><input className="form-input mt-1" value={form.address} onChange={e => u('address', e.target.value)} required placeholder="Full address" /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="form-label">Phone</label><input className="form-input mt-1" value={form.phone} onChange={e => u('phone', e.target.value)} placeholder="Phone" /></div>
        <div><label className="form-label">Mobile</label><input className="form-input mt-1" value={form.mobile} onChange={e => u('mobile', e.target.value)} placeholder="Mobile" /></div>
        <div><label className="form-label">Fax</label><input className="form-input mt-1" value={form.fax} onChange={e => u('fax', e.target.value)} placeholder="Fax" /></div>
        <div><label className="form-label">TIN Number</label><input className="form-input mt-1" value={form.tinNumber} onChange={e => u('tinNumber', e.target.value)} placeholder="Tax ID" /></div>
      </div>

      {/* Primary Banking */}
      <h3 className="text-sm font-semibold text-primary pt-2 border-t">Primary Lessor Bank Details</h3>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="form-label">Account Name</label><input className="form-input mt-1" value={form.bankAccountName || ''} onChange={e => u('bankAccountName', e.target.value)} placeholder="Account name" /></div>
        <div><label className="form-label">Account Number</label><input className="form-input mt-1" value={form.bankAccount || ''} onChange={e => u('bankAccount', e.target.value)} placeholder="Account #" /></div>
        <div><label className="form-label">Bank Name</label><input className="form-input mt-1" value={form.bankName || ''} onChange={e => u('bankName', e.target.value)} placeholder="Bank name" /></div>
        <div><label className="form-label">Branch</label><input className="form-input mt-1" value={form.bankBranch || ''} onChange={e => u('bankBranch', e.target.value)} placeholder="Branch" /></div>
      </div>

      {/* Guardian Banking */}
      <h3 className="text-sm font-semibold text-primary pt-2 border-t">Guardian Bank Details (Optional)</h3>
      <div className="grid grid-cols-2 gap-3">
        <div className="col-span-2"><label className="form-label">Guardian Name</label><input className="form-input mt-1" value={form.guardianName || ''} onChange={e => u('guardianName', e.target.value)} placeholder="Guardian name" /></div>
        <div><label className="form-label">Account Name</label><input className="form-input mt-1" value={form.guardianAccountName || ''} onChange={e => u('guardianAccountName', e.target.value)} placeholder="Account name" /></div>
        <div><label className="form-label">Account Number</label><input className="form-input mt-1" value={form.guardianAccountNumber || ''} onChange={e => u('guardianAccountNumber', e.target.value)} placeholder="Account #" /></div>
        <div><label className="form-label">Bank Name</label><input className="form-input mt-1" value={form.guardianBankName || ''} onChange={e => u('guardianBankName', e.target.value)} placeholder="Bank name" /></div>
        <div><label className="form-label">Branch</label><input className="form-input mt-1" value={form.guardianBranch || ''} onChange={e => u('guardianBranch', e.target.value)} placeholder="Branch" /></div>
      </div>

      <div className="flex gap-2 pt-2">
        <button type="submit" className="btn-primary">Save</button>
        <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

function LessorDetail({ lessor }: { lessor: Lessor }) {
  return (
    <div className="space-y-5">
      <h2 className="text-lg font-semibold text-foreground">Lessor Details</h2>
      <DetailSection title="Personal Information" rows={[
        ['Full Name', lessor.fullName], ['Address', lessor.address],
        ['Phone', lessor.phone || 'N/A'], ['Mobile', lessor.mobile || 'N/A'],
        ['Fax', lessor.fax || 'N/A'], ['TIN Number', lessor.tinNumber || 'N/A'],
        ['Is Guardian', lessor.isGuardian ? 'Yes' : 'No'],
      ]} />
      <DetailSection title="Primary Lessor Bank Details" rows={[
        ['Account Name', lessor.bankAccountName || 'N/A'],
        ['Account Number', lessor.bankAccount || 'N/A'],
        ['Bank Name', lessor.bankName || 'N/A'],
        ['Branch', lessor.bankBranch || 'N/A'],
      ]} copyable />
      {lessor.guardianName && (
        <DetailSection title="Guardian Bank Details" rows={[
          ['Guardian Name', lessor.guardianName || 'N/A'],
          ['Account Name', lessor.guardianAccountName || 'N/A'],
          ['Account Number', lessor.guardianAccountNumber || 'N/A'],
          ['Bank Name', lessor.guardianBankName || 'N/A'],
          ['Branch', lessor.guardianBranch || 'N/A'],
        ]} copyable />
      )}
    </div>
  );
}

function DetailSection({ title, rows, copyable }: { title: string; rows: [string, string][]; copyable?: boolean }) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-primary mb-2">{title}</h3>
      <div className="bg-muted/50 rounded-md p-3 space-y-1.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex text-sm items-center">
            <span className="w-36 text-muted-foreground shrink-0">{k}:</span>
            <span className="text-foreground flex-1">{v}</span>
            {copyable && v !== 'N/A' && <CopyField label="" value={v} />}
          </div>
        ))}
      </div>
    </div>
  );
}
