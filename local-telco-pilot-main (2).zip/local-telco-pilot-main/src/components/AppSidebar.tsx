import { useLocation, useNavigate, Link } from 'react-router-dom';
import { LayoutDashboard, Radio, Users, FileText, LogOut, Menu, X, CreditCard, AlertTriangle, Settings } from 'lucide-react';
import { logout } from '@/lib/store';
import { useState } from 'react';
import logo from '@/assets/logo.png';

const links = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/sites', label: 'Sites', icon: Radio },
  { to: '/lessors', label: 'Lessors', icon: Users },
  { to: '/leases', label: 'Leases', icon: FileText },
  { to: '/payments', label: 'Payments', icon: CreditCard },
  { to: '/issues', label: 'Issues', icon: AlertTriangle },
  { to: '/admin-settings', label: 'Admin Settings', icon: Settings },
];

export default function AppSidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleLogout = () => { logout(); navigate('/login'); };

  // Get current page title
  const currentPage = links.find(l => 
    location.pathname === l.to || (l.to !== '/' && location.pathname.startsWith(l.to))
  );
  const pageTitle = currentPage?.label || 'Dashboard';

  const nav = (
    <>
      <div className="px-4 py-6">
        <div className="flex items-center gap-2">
          <img src={logo} alt="Vodafone" className="w-8 h-8 rounded-full object-cover" />
          <div>
            <h1 className="text-base font-bold text-sidebar-active-fg leading-tight">Vodafone</h1>
            <p className="text-[10px] text-sidebar-fg leading-tight">Site Manager</p>
          </div>
        </div>
      </div>
      <nav className="flex-1 px-2 space-y-1">
        {links.map(l => {
          const active = location.pathname === l.to || (l.to !== '/' && location.pathname.startsWith(l.to));
          return (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${active ? 'bg-sidebar-active text-sidebar-active-fg' : 'text-sidebar-fg hover:bg-sidebar-hover'}`}>
              <l.icon size={18} />
              {l.label}
            </Link>
          );
        })}
      </nav>
      <div className="px-2 pb-4">
        <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-sidebar-fg hover:bg-sidebar-hover w-full transition-colors">
          <LogOut size={18} /> Logout
        </button>
      </div>
    </>
  );

  return (
    <>
      {/* Mobile top bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-12 bg-sidebar-bg flex items-center px-3 gap-3 shadow-sm lg:hidden">
        <button onClick={() => setOpen(!open)} className="p-1.5 rounded-md text-sidebar-fg hover:bg-sidebar-hover">
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
        <img src={logo} alt="Vodafone" className="w-6 h-6 rounded-full object-cover" />
        <span className="text-sm font-semibold text-sidebar-active-fg">{pageTitle}</span>
      </div>


      {/* Overlay */}
      {open && <div className="fixed inset-0 bg-foreground/30 z-30 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-60 bg-sidebar-bg flex flex-col transition-transform lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'} lg:block`}>
        {nav}
      </aside>
    </>
  );
}
