import { useState, useRef, useCallback } from 'react';
import { X, Upload, FileText, Loader2, CheckCircle, AlertCircle, ScanLine, ChevronDown, ChevronUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Site, Lessor, Lease } from '@/lib/types';
import { addSite, addLessor, addLease, getSites, getLessors } from '@/lib/store';

interface ExtractedData {
  lessor: Partial<Lessor>;
  site: Partial<Site>;
  lease: Partial<Lease>;
  confidence: 'high' | 'medium' | 'low';
  summary: string;
}

type Step = 'upload' | 'processing' | 'review' | 'error';

interface Props {
  onClose: () => void;
  onComplete: () => void;
}

export default function DocumentScanModal({ onClose, onComplete }: Props) {
  const [step, setStep] = useState<Step>('upload');
  const [error, setError] = useState('');
  const [fileName, setFileName] = useState('');
  const [data, setData] = useState<ExtractedData | null>(null);
  const [editedLessor, setEditedLessor] = useState<Partial<Lessor>>({});
  const [editedSite, setEditedSite] = useState<Partial<Site>>({});
  const [editedLease, setEditedLease] = useState<Partial<Lease>>({});
  const [saveLessorEnabled, setSaveLessorEnabled] = useState(true);
  const [saveSiteEnabled, setSaveSiteEnabled] = useState(true);
  const [saveLeaseEnabled, setSaveLeaseEnabled] = useState(true);
  const [expandedSection, setExpandedSection] = useState<string | null>('lessor');
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);

  const processFile = useCallback(async (file: File) => {
    const maxSize = 20 * 1024 * 1024;
    if (file.size > maxSize) {
      setError('File too large. Maximum size is 20MB.');
      setStep('error');
      return;
    }

    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/jpg'];
    if (!allowed.includes(file.type)) {
      setError('Unsupported file type. Please upload PDF, JPG, or PNG.');
      setStep('error');
      return;
    }

    setFileName(file.name);
    setStep('processing');

    try {
      const base64 = await fileToBase64(file);

      const { data: result, error: fnError } = await supabase.functions.invoke('extract-document', {
        body: { fileBase64: base64, fileType: file.type, fileName: file.name },
      });

      if (fnError) throw new Error(fnError.message || 'Extraction failed');
      if (!result?.success) throw new Error(result?.error || 'AI extraction failed');

      const extracted = result.data as ExtractedData;
      setData(extracted);

      // Ensure site code has VP prefix
      if (extracted.site?.code && !extracted.site.code.toUpperCase().startsWith('VP')) {
        extracted.site.code = 'VP' + extracted.site.code.replace(/\D/g, '');
      }

      setEditedLessor(extracted.lessor || {});
      setEditedSite({ ...(extracted.site || {}), status: 'Pending' as const });
      setEditedLease(extracted.lease || {});

      // Check if data was found
      setSaveLessorEnabled(!!extracted.lessor?.fullName);
      setSaveSiteEnabled(!!extracted.site?.name);
      setSaveLeaseEnabled(!!extracted.lease?.startDate || !!extracted.lease?.monthlyPayment);

      setStep('review');
    } catch (e: any) {
      console.error('Document extraction error:', e);
      setError(e.message || 'Failed to process document');
      setStep('error');
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      let newLessorId = '';
      let newSiteId = '';

      // Save Lessor
      if (saveLessorEnabled && editedLessor.fullName) {
        const lessor: Lessor = {
          id: crypto.randomUUID(),
          fullName: editedLessor.fullName || '',
          isGuardian: editedLessor.isGuardian || false,
          address: editedLessor.address || '',
          phone: editedLessor.phone || '',
          mobile: editedLessor.mobile || '',
          fax: 'N/A',
          tinNumber: editedLessor.tinNumber || '',
          bankName: editedLessor.bankName || '',
          bankBranch: editedLessor.bankBranch || '',
          bankAccount: editedLessor.bankAccount || '',
          bankAccountName: editedLessor.bankAccountName || '',
        };
        newLessorId = lessor.id;
        addLessor(lessor);
      }

      // Save Site
      if (saveSiteEnabled && editedSite.name) {
        const site: Site = {
          id: crypto.randomUUID(),
          name: editedSite.name || '',
          code: editedSite.code || 'VP',
          province: editedSite.province || '',
          address: editedSite.address || '',
          latitude: editedSite.latitude || '',
          longitude: editedSite.longitude || '',
          landType: editedSite.landType || '',
          lessorId: newLessorId,
          status: 'Pending',
          buildStatus: editedSite.buildStatus || 'N/A',
          associatedUser: '',
          associatedEmail: '',
        };
        newSiteId = site.id;
        addSite(site);
      }

      // Save Lease
      if (saveLeaseEnabled && (editedLease.startDate || editedLease.monthlyPayment)) {
        const leaseTerm = editedLease.leaseTerm || '10';
        let endDate = '';
        if (editedLease.startDate && leaseTerm) {
          const start = new Date(editedLease.startDate);
          const years = parseInt(leaseTerm);
          if (!isNaN(years)) {
            const end = new Date(start);
            end.setFullYear(end.getFullYear() + years);
            endDate = end.toISOString().split('T')[0];
          }
        }

        const lease: Lease = {
          id: crypto.randomUUID(),
          siteId: newSiteId,
          lessorId: newLessorId,
          startDate: editedLease.startDate || '',
          endDate,
          leaseTerm,
          monthlyPayment: editedLease.monthlyPayment || '',
          gstApplicable: editedLease.gstApplicable || false,
          rentalRate: '',
          installments: '',
          amountPayable: '',
          rentalIncrease: '',
          sgRate: 'N/A',
          sgStartDate: editedLease.startDate || '',
          specialRemarks: editedLease.specialRemarks || '',
          escalationType: editedLease.escalationType || 'None',
          escalationStartYear: editedLease.escalationStartYear || 6,
          escalationRate: editedLease.escalationRate || 0,
          escalationInterval: 1,
        };
        addLease(lease);
      }

      onComplete();
      onClose();
    } catch (e: any) {
      setError(e.message || 'Failed to save records');
      setStep('error');
    } finally {
      setSaving(false);
    }
  };

  const confidenceColor = data?.confidence === 'high' ? 'text-success' : data?.confidence === 'medium' ? 'text-warning' : 'text-destructive';

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={onClose}>
      <div className="bg-card rounded-lg border shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto relative" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 bg-card border-b p-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <ScanLine size={20} className="text-primary" />
            <h2 className="text-lg font-semibold text-foreground">AI Document Scanner</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X size={18} /></button>
        </div>

        <div className="p-6">
          {/* UPLOAD STEP */}
          {step === 'upload' && (
            <div
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${dragOver ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'}`}
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
            >
              <Upload size={48} className="mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Upload Document</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Drag & drop or click to upload a lease agreement, site document, or scanned form
              </p>
              <p className="text-xs text-muted-foreground mb-6">Supports PDF, JPG, PNG (max 20MB)</p>
              <input ref={fileRef} type="file" accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileChange} className="hidden" />
              <button onClick={() => fileRef.current?.click()} className="btn-primary gap-2">
                <Upload size={16} /> Choose File
              </button>
            </div>
          )}

          {/* PROCESSING STEP */}
          {step === 'processing' && (
            <div className="text-center py-12">
              <Loader2 size={48} className="mx-auto text-primary animate-spin mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Analyzing Document</h3>
              <p className="text-sm text-muted-foreground mb-1">Processing: {fileName}</p>
              <p className="text-xs text-muted-foreground">AI is extracting lessor, site, and lease information...</p>
            </div>
          )}

          {/* ERROR STEP */}
          {step === 'error' && (
            <div className="text-center py-12">
              <AlertCircle size={48} className="mx-auto text-destructive mb-4" />
              <h3 className="text-lg font-medium text-foreground mb-2">Extraction Failed</h3>
              <p className="text-sm text-destructive mb-6">{error}</p>
              <button onClick={() => { setStep('upload'); setError(''); }} className="btn-primary">Try Again</button>
            </div>
          )}

          {/* REVIEW STEP */}
          {step === 'review' && data && (
            <div className="space-y-4">
              {/* Summary */}
              <div className="rounded-lg bg-muted/50 p-4 flex items-start gap-3">
                <CheckCircle size={20} className="text-success mt-0.5 shrink-0" />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-foreground">Extraction Complete</span>
                    <span className={`text-xs font-medium ${confidenceColor}`}>
                      ({data.confidence} confidence)
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">{data.summary}</p>
                </div>
              </div>

              {/* Lessor Section */}
              <ReviewSection
                title="Lessor Information"
                enabled={saveLessorEnabled}
                onToggle={() => setSaveLessorEnabled(!saveLessorEnabled)}
                expanded={expandedSection === 'lessor'}
                onExpand={() => setExpandedSection(expandedSection === 'lessor' ? null : 'lessor')}
                hasData={!!editedLessor.fullName}
              >
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Full Name" value={editedLessor.fullName || ''} onChange={v => setEditedLessor(p => ({ ...p, fullName: v }))} />
                  <Field label="Address" value={editedLessor.address || ''} onChange={v => setEditedLessor(p => ({ ...p, address: v }))} />
                  <Field label="Phone" value={editedLessor.phone || ''} onChange={v => setEditedLessor(p => ({ ...p, phone: v }))} />
                  <Field label="Mobile" value={editedLessor.mobile || ''} onChange={v => setEditedLessor(p => ({ ...p, mobile: v }))} />
                  <Field label="TIN Number" value={editedLessor.tinNumber || ''} onChange={v => setEditedLessor(p => ({ ...p, tinNumber: v }))} />
                  <Field label="Bank Name" value={editedLessor.bankName || ''} onChange={v => setEditedLessor(p => ({ ...p, bankName: v }))} />
                  <Field label="Branch" value={editedLessor.bankBranch || ''} onChange={v => setEditedLessor(p => ({ ...p, bankBranch: v }))} />
                  <Field label="Account Name" value={editedLessor.bankAccountName || ''} onChange={v => setEditedLessor(p => ({ ...p, bankAccountName: v }))} />
                  <Field label="Account Number" value={editedLessor.bankAccount || ''} onChange={v => setEditedLessor(p => ({ ...p, bankAccount: v }))} />
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={editedLessor.isGuardian || false} onChange={e => setEditedLessor(p => ({ ...p, isGuardian: e.target.checked }))} className="rounded" />
                    <label className="text-sm text-foreground">Is Guardian</label>
                  </div>
                </div>
              </ReviewSection>

              {/* Site Section */}
              <ReviewSection
                title="Site Information"
                enabled={saveSiteEnabled}
                onToggle={() => setSaveSiteEnabled(!saveSiteEnabled)}
                expanded={expandedSection === 'site'}
                onExpand={() => setExpandedSection(expandedSection === 'site' ? null : 'site')}
                hasData={!!editedSite.name}
              >
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Site Name" value={editedSite.name || ''} onChange={v => setEditedSite(p => ({ ...p, name: v }))} />
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">Site Code</label>
                    <div className="flex mt-1">
                      <span className="inline-flex items-center px-2.5 rounded-l-md border border-r-0 bg-muted text-sm font-semibold text-primary">VP</span>
                      <input
                        className="form-input rounded-l-none flex-1"
                        value={(editedSite.code || '').replace(/^VP/i, '')}
                        onChange={e => setEditedSite(p => ({ ...p, code: 'VP' + e.target.value.replace(/[^0-9]/g, '') }))}
                        placeholder="1001"
                      />
                    </div>
                  </div>
                  <Field label="Province" value={editedSite.province || ''} onChange={v => setEditedSite(p => ({ ...p, province: v }))} />
                  <Field label="Address" value={editedSite.address || ''} onChange={v => setEditedSite(p => ({ ...p, address: v }))} />
                  <Field label="Latitude" value={editedSite.latitude || ''} onChange={v => setEditedSite(p => ({ ...p, latitude: v }))} />
                  <Field label="Longitude" value={editedSite.longitude || ''} onChange={v => setEditedSite(p => ({ ...p, longitude: v }))} />
                  <Field label="Land Type" value={editedSite.landType || ''} onChange={v => setEditedSite(p => ({ ...p, landType: v }))} />
                  <Field label="Build Status" value={editedSite.buildStatus || ''} onChange={v => setEditedSite(p => ({ ...p, buildStatus: v }))} />
                </div>
              </ReviewSection>

              {/* Lease Section */}
              <ReviewSection
                title="Lease Information"
                enabled={saveLeaseEnabled}
                onToggle={() => setSaveLeaseEnabled(!saveLeaseEnabled)}
                expanded={expandedSection === 'lease'}
                onExpand={() => setExpandedSection(expandedSection === 'lease' ? null : 'lease')}
                hasData={!!editedLease.startDate || !!editedLease.monthlyPayment}
              >
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Start Date" value={editedLease.startDate || ''} onChange={v => setEditedLease(p => ({ ...p, startDate: v }))} type="date" />
                  <Field label="Lease Term (Years)" value={editedLease.leaseTerm || ''} onChange={v => setEditedLease(p => ({ ...p, leaseTerm: v }))} />
                  <Field label="Monthly Payment" value={editedLease.monthlyPayment || ''} onChange={v => setEditedLease(p => ({ ...p, monthlyPayment: v }))} />
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={editedLease.gstApplicable || false} onChange={e => setEditedLease(p => ({ ...p, gstApplicable: e.target.checked }))} className="rounded" />
                    <label className="text-sm text-foreground">GST Applicable</label>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-muted-foreground">Escalation Type</label>
                    <select className="form-input mt-1" value={editedLease.escalationType || 'None'} onChange={e => {
                      const val = e.target.value as 'None' | 'CPI' | 'Fixed';
                      setEditedLease(p => ({
                        ...p,
                        escalationType: val,
                        escalationStartYear: val === 'CPI' ? 6 : p.escalationStartYear,
                      }));
                    }}>
                      <option value="None">None</option>
                      <option value="CPI">CPI</option>
                      <option value="Fixed">Fixed %</option>
                    </select>
                  </div>
                  {editedLease.escalationType && editedLease.escalationType !== 'None' && (
                    <>
                      <Field label="Escalation Start Year" value={String(editedLease.escalationStartYear || 6)} onChange={v => setEditedLease(p => ({ ...p, escalationStartYear: parseInt(v) || 6 }))} />
                      <Field label="Escalation Rate (%)" value={String(editedLease.escalationRate || 0)} onChange={v => setEditedLease(p => ({ ...p, escalationRate: parseFloat(v) || 0 }))} />
                    </>
                  )}
                  <div className="col-span-2">
                    <label className="text-xs font-medium text-muted-foreground">Special Remarks</label>
                    <textarea className="form-input mt-1" rows={2} value={editedLease.specialRemarks || ''} onChange={e => setEditedLease(p => ({ ...p, specialRemarks: e.target.value }))} />
                  </div>
                </div>
              </ReviewSection>

              {/* Actions */}
              <div className="flex gap-2 pt-2 border-t">
                <button onClick={handleSave} disabled={saving} className="btn-primary gap-2 flex-1">
                  {saving ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />}
                  {saving ? 'Saving...' : 'Create Records'}
                </button>
                <button onClick={onClose} className="btn-secondary">Cancel</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ReviewSection({ title, enabled, onToggle, expanded, onExpand, hasData, children }: {
  title: string; enabled: boolean; onToggle: () => void;
  expanded: boolean; onExpand: () => void; hasData: boolean; children: React.ReactNode;
}) {
  return (
    <div className={`rounded-lg border transition-colors ${enabled ? 'border-border' : 'border-border/50 opacity-60'}`}>
      <div className="flex items-center justify-between p-3 cursor-pointer" onClick={onExpand}>
        <div className="flex items-center gap-2">
          <input type="checkbox" checked={enabled} onChange={e => { e.stopPropagation(); onToggle(); }} className="rounded" />
          <span className="text-sm font-medium text-foreground">{title}</span>
          {hasData ? (
            <span className="text-xs bg-success/15 text-success px-1.5 py-0.5 rounded">Detected</span>
          ) : (
            <span className="text-xs bg-muted text-muted-foreground px-1.5 py-0.5 rounded">No data</span>
          )}
        </div>
        {expanded ? <ChevronUp size={16} className="text-muted-foreground" /> : <ChevronDown size={16} className="text-muted-foreground" />}
      </div>
      {expanded && enabled && <div className="p-3 pt-0">{children}</div>}
    </div>
  );
}

function Field({ label, value, onChange, type = 'text' }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="text-xs font-medium text-muted-foreground">{label}</label>
      <input type={type} className="form-input mt-1" value={value} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove the data:...;base64, prefix
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
