import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Site } from '@/lib/types';
import { getLessors } from '@/lib/store';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

interface Props {
  sites: Site[];
  onReportIssue?: (site: Site) => void;
}

export default function SiteMap({ sites, onReportIssue }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!ref.current) return;
    if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }

    const map = L.map(ref.current).setView([-6.0, 147.0], 6);
    mapRef.current = map;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
    }).addTo(map);

    const lessors = getLessors();
    const bounds: L.LatLngExpression[] = [];

    sites.forEach(site => {
      const lat = parseFloat(site.latitude);
      const lng = parseFloat(site.longitude);
      if (isNaN(lat) || isNaN(lng)) return;
      bounds.push([lat, lng]);
      const lessor = lessors.find(l => l.id === site.lessorId);
      const statusColor = site.status === 'Active' ? '#22c55e' : site.status === 'Pending' ? '#f59e0b' : '#94a3b8';

      const popupContent = document.createElement('div');
      popupContent.style.fontSize = '13px';
      popupContent.style.minWidth = '200px';
      popupContent.innerHTML = `
        <b>${site.name}</b> <span style="color:${statusColor};font-weight:600">(${site.status})</span><br/>
        <b>Code:</b> ${site.code}<br/>
        <b>Province:</b> ${site.province}<br/>
        <b>Address:</b> ${site.address}<br/>
        <b>Lat:</b> ${site.latitude}<br/>
        <b>Lng:</b> ${site.longitude}<br/>
        <b>Land Type:</b> ${site.landType}<br/>
        <b>Build Status:</b> ${site.buildStatus}<br/>
        <b>Lessor:</b> ${lessor?.fullName || 'N/A'}<br/>
        <b>User:</b> ${site.associatedUser || 'N/A'}<br/>
        <b>Email:</b> ${site.associatedEmail || 'N/A'}
      `;

      if (onReportIssue) {
        const btn = document.createElement('button');
        btn.textContent = '⚠ Report Issue';
        btn.style.cssText = 'display:block;width:100%;margin-top:8px;padding:6px 12px;background:hsl(0,100%,45%);color:white;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;';
        btn.addEventListener('click', () => onReportIssue(site));
        popupContent.appendChild(btn);
      }

      L.marker([lat, lng]).addTo(map).bindPopup(popupContent);
    });

    if (bounds.length > 0) {
      map.fitBounds(bounds as L.LatLngBoundsExpression, { padding: [30, 30], maxZoom: 12 });
    }

    return () => { map.remove(); mapRef.current = null; };
  }, [sites, onReportIssue]);

  return <div ref={ref} className="w-full h-[400px] rounded-lg border relative z-0" />;
}
