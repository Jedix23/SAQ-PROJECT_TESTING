import { useState } from 'react';
import { Site } from '@/lib/types';
import { X } from 'lucide-react';

export default function SiteFormModal({ site, lessors, onSave, onClose }: {
  site: Site;
  lessors: any[];
  onSave: (s: Site) => void;
  onClose: () => void;
}) {
  const [form, setForm] = useState(site);
  const u = (k: keyof Site, v: string) => setForm({ ...form, [k]: v });

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={onClose}>
      <div className="bg-card rounded-lg border shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 relative animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>
        <h2 className="text-lg font-semibold text-foreground mb-1">{site.id ? 'Edit Site' : 'New Site'}</h2>
        <p className="text-sm text-muted-foreground mb-4">{site.id ? 'Update site details below' : 'Fill in the details to create a new site'}</p>
        <form onSubmit={e => { e.preventDefault(); onSave(form); }} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="form-label">Name *</label><input className="form-input mt-1" value={form.name} onChange={e => u('name', e.target.value)} required placeholder="Site name" /></div>
            <div>
              <label className="form-label">Code *</label>
              <div className="relative mt-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-semibold text-primary">VP</span>
                <input
                  className="form-input pl-9 font-mono"
                  value={form.code.replace(/^VP/i, '')}
                  onChange={e => {
                    const num = e.target.value.replace(/[^0-9]/g, '');
                    u('code', 'VP' + num);
                  }}
                  required
                  placeholder="1001"
                />
              </div>
            </div>
            <div><label className="form-label">Province</label><input className="form-input mt-1" value={form.province} onChange={e => u('province', e.target.value)} placeholder="Province" /></div>
            <div><label className="form-label">Address</label><input className="form-input mt-1" value={form.address} onChange={e => u('address', e.target.value)} placeholder="Full address" /></div>
            <div><label className="form-label">Latitude</label><input className="form-input mt-1" value={form.latitude} onChange={e => u('latitude', e.target.value)} placeholder="-6.7340" /></div>
            <div><label className="form-label">Longitude</label><input className="form-input mt-1" value={form.longitude} onChange={e => u('longitude', e.target.value)} placeholder="147.0030" /></div>
            <div><label className="form-label">Land Type</label><input className="form-input mt-1" value={form.landType} onChange={e => u('landType', e.target.value)} placeholder="Customary / State" /></div>
            <div>
              <label className="form-label">Status *</label>
              <select className="form-input mt-1" value={form.status} onChange={e => u('status', e.target.value as any)}>
                <option>Active</option><option>Pending</option><option>Inactive</option>
              </select>
            </div>
            <div><label className="form-label">Build Status</label><input className="form-input mt-1" value={form.buildStatus} onChange={e => u('buildStatus', e.target.value)} placeholder="N/A / Complete / In Progress" /></div>
            <div>
              <label className="form-label">Lessor</label>
              <select className="form-input mt-1" value={form.lessorId} onChange={e => u('lessorId', e.target.value)}>
                <option value="">-- Select --</option>
                {lessors.map(l => <option key={l.id} value={l.id}>{l.fullName}</option>)}
              </select>
            </div>
            <div><label className="form-label">Associated User</label><input className="form-input mt-1" value={form.associatedUser} onChange={e => u('associatedUser', e.target.value)} placeholder="User name" /></div>
            <div><label className="form-label">Email</label><input className="form-input mt-1" value={form.associatedEmail} onChange={e => u('associatedEmail', e.target.value)} placeholder="user@email.com" /></div>
          </div>
          <div className="flex gap-2 pt-3 border-t">
            <button type="submit" className="btn-primary flex-1">Save Site</button>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
