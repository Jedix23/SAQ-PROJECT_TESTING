import { Site, Lessor } from '@/lib/types';
import { X, MapPin, User, Building } from 'lucide-react';

export default function SiteDetailModal({ site, lessor, onClose }: {
  site: Site;
  lessor?: Lessor;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-foreground/30 p-4" onClick={onClose}>
      <div className="bg-card rounded-lg border shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 relative animate-in fade-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"><X size={18} /></button>

        <div className="flex items-start gap-3 mb-5">
          <div className="rounded-lg bg-primary/10 p-2.5 text-primary"><MapPin size={20} /></div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">{site.name}</h2>
            <p className="text-sm text-muted-foreground font-mono">{site.code}</p>
          </div>
        </div>

        <Section icon={<Building size={15} />} title="Site Information" rows={[
          ['Province', site.province || '—'],
          ['Address', site.address || '—'],
          ['Status', site.status],
          ['Build Status', site.buildStatus || '—'],
          ['Land Type', site.landType || '—'],
          ['Latitude', site.latitude || '—'],
          ['Longitude', site.longitude || '—'],
        ]} />

        <Section icon={<User size={15} />} title="Contact" rows={[
          ['Associated User', site.associatedUser || '—'],
          ['Email', site.associatedEmail || '—'],
          ['Account/Lessor', lessor?.fullName || '—'],
        ]} />

        {lessor && (
          <Section icon={<Building size={15} />} title="Lessor Details" rows={[
            ['Name', lessor.fullName],
            ['Address', lessor.address || '—'],
            ['Phone', lessor.phone || '—'],
            ['TIN', lessor.tinNumber || '—'],
          ]} />
        )}
      </div>
    </div>
  );
}

function Section({ icon, title, rows }: { icon: React.ReactNode; title: string; rows: [string, string][] }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="text-primary">{icon}</span>
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      </div>
      <div className="bg-muted/40 rounded-md p-3 space-y-1.5">
        {rows.map(([k, v]) => (
          <div key={k} className="flex text-sm">
            <span className="w-36 text-muted-foreground shrink-0">{k}</span>
            <span className="text-foreground">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
