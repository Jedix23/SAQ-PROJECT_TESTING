import { useState, useEffect } from 'react';
import { X, AlertTriangle, Send } from 'lucide-react';
import { Site } from '@/lib/types';
import { fetchCategories, createIssue, logEmail, getEmailsForCategory, IssueCategory } from '@/lib/issues';
import { toast } from 'sonner';

interface Props {
  site: Site;
  onClose: () => void;
  onCreated?: () => void;
}

export default function ReportIssueModal({ site, onClose, onCreated }: Props) {
  const [categories, setCategories] = useState<IssueCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    reporterName: '',
    reporterDepartment: '',
    category: '',
    description: '',
    priority: 'Medium' as 'Low' | 'Medium' | 'High',
  });

  useEffect(() => {
    fetchCategories().then(setCategories).catch(console.error);
  }, []);

  const handleSubmit = async () => {
    if (!form.reporterName || !form.category || !form.description) {
      toast.error('Please fill in all required fields');
      return;
    }
    setLoading(true);
    try {
      const issue = await createIssue({
        site_id: site.id,
        site_name: site.name,
        site_code: site.code,
        site_location: `${site.province}, ${site.address}`,
        reporter_name: form.reporterName,
        reporter_department: form.reporterDepartment,
        category: form.category,
        description: form.description,
        priority: form.priority,
        status: 'Open',
        officer_name: null,
        root_cause: null,
        action_taken: null,
        date_reported: new Date().toISOString(),
        date_assigned: null,
        date_closed: null,
      });

      // Log email notification
      const emails = await getEmailsForCategory(form.category);
      if (emails.to.length > 0 || emails.cc.length > 0) {
        const subject = `New Issue Reported: ${site.name} (${site.code}) - ${form.category}`;
        const body = `Hello Team,\n\nA new site acquisition issue has been reported.\n\nSite Name: ${site.name}\nSite ID: ${site.code}\nLocation: ${site.province}, ${site.address}\n\nReported By: ${form.reporterName}\nDepartment: ${form.reporterDepartment}\nDate Reported: ${new Date().toLocaleString()}\n\nIssue Category: ${form.category}\nPriority: ${form.priority}\nIssue Description: ${form.description}\n\nView in Site Acquisition Web App.\n\nRegards,\nSAQ Team`;
        await logEmail(issue.id, 'new_issue', emails.to, emails.cc, subject, body);
        toast.success(`Issue reported! Email notification logged to ${emails.to.length + emails.cc.length} recipient(s)`);
      } else {
        toast.success('Issue reported successfully');
      }

      onCreated?.();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create issue');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto border">
        <div className="flex items-center justify-between p-5 border-b bg-destructive/5">
          <div className="flex items-center gap-2">
            <AlertTriangle size={20} className="text-destructive" />
            <h2 className="text-lg font-bold text-foreground">Report Issue</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-muted transition-colors">
            <X size={18} className="text-muted-foreground" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Site Info (auto-filled) */}
          <div className="rounded-lg bg-muted/50 p-3 space-y-1">
            <p className="text-xs font-medium text-muted-foreground">SITE INFORMATION</p>
            <p className="text-sm font-semibold text-foreground">{site.name} ({site.code})</p>
            <p className="text-xs text-muted-foreground">{site.province}, {site.address}</p>
            <p className="text-xs text-muted-foreground">
              {new Date().toLocaleString()}
            </p>
          </div>

          {/* Reporter Info */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="form-label">Reporter Name <span className="text-destructive">*</span></label>
              <input className="form-input mt-1" placeholder="Your name" value={form.reporterName} onChange={e => setForm({ ...form, reporterName: e.target.value })} />
            </div>
            <div>
              <label className="form-label">Department</label>
              <input className="form-input mt-1" placeholder="Your department" value={form.reporterDepartment} onChange={e => setForm({ ...form, reporterDepartment: e.target.value })} />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="form-label">Issue Category <span className="text-destructive">*</span></label>
            <select className="form-input mt-1" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
              <option value="">Select category...</option>
              {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
            </select>
          </div>

          {/* Priority */}
          <div>
            <label className="form-label">Priority Level</label>
            <div className="flex gap-2 mt-1">
              {(['Low', 'Medium', 'High'] as const).map(p => (
                <button key={p} onClick={() => setForm({ ...form, priority: p })}
                  className={`flex-1 py-2 rounded-md text-sm font-medium border transition-colors ${
                    form.priority === p
                      ? p === 'High' ? 'bg-destructive text-destructive-foreground border-destructive'
                        : p === 'Medium' ? 'bg-warning text-warning-foreground border-warning'
                        : 'bg-success text-success-foreground border-success'
                      : 'bg-background text-muted-foreground border-border hover:bg-muted'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="form-label">Issue Description <span className="text-destructive">*</span></label>
            <textarea className="form-input mt-1 min-h-[100px]" placeholder="Describe the issue in detail..." value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          </div>
        </div>

        <div className="p-5 border-t flex gap-2 justify-end">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary gap-2">
            <Send size={16} />
            {loading ? 'Submitting...' : 'Submit Report'}
          </button>
        </div>
      </div>
    </div>
  );
}
