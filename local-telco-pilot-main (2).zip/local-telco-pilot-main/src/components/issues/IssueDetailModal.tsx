import { useState, useEffect } from 'react';
import { X, Upload, CheckCircle, Clock, AlertTriangle, Camera } from 'lucide-react';
import { SiteIssue, IssuePhoto, updateIssue, fetchIssuePhotos, uploadIssuePhoto, logEmail, getEmailsForCategory } from '@/lib/issues';
import { toast } from 'sonner';

interface Props {
  issue: SiteIssue;
  onClose: () => void;
  onUpdated?: () => void;
}

const statusOptions = ['Open', 'Work In Progress', 'Waiting for Approval', 'Resolved'];
const priorityColors: Record<string, string> = {
  High: 'bg-destructive/15 text-destructive border-destructive/20',
  Medium: 'bg-warning/15 text-warning border-warning/20',
  Low: 'bg-success/15 text-success border-success/20',
};
const statusColors: Record<string, string> = {
  Open: 'bg-destructive/15 text-destructive border-destructive/20',
  'Work In Progress': 'bg-info/15 text-info border-info/20',
  'Waiting for Approval': 'bg-warning/15 text-warning border-warning/20',
  Resolved: 'bg-success/15 text-success border-success/20',
};

export default function IssueDetailModal({ issue, onClose, onUpdated }: Props) {
  const [photos, setPhotos] = useState<IssuePhoto[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({
    officerName: issue.officer_name || '',
    rootCause: issue.root_cause || '',
    actionTaken: issue.action_taken || '',
    status: issue.status,
  });

  useEffect(() => {
    fetchIssuePhotos(issue.id).then(setPhotos).catch(console.error);
  }, [issue.id]);

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files?.length) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        await uploadIssuePhoto(issue.id, file);
      }
      const updated = await fetchIssuePhotos(issue.id);
      setPhotos(updated);
      toast.success('Photo(s) uploaded');
    } catch (err: any) {
      toast.error(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleUpdate = async () => {
    if (!form.officerName) {
      toast.error('Please enter officer name');
      return;
    }
    setLoading(true);
    try {
      const updates: Partial<SiteIssue> = {
        officer_name: form.officerName,
        root_cause: form.rootCause,
        action_taken: form.actionTaken,
        status: form.status,
      };

      if (form.status !== issue.status) {
        if (form.status === 'Work In Progress' && !issue.date_assigned) {
          updates.date_assigned = new Date().toISOString();
        }
        if (form.status === 'Resolved') {
          updates.date_closed = new Date().toISOString();
        }
      }

      await updateIssue(issue.id, updates);

      // Send resolution email if resolved
      if (form.status === 'Resolved' && issue.status !== 'Resolved') {
        const emails = await getEmailsForCategory(issue.category);
        if (emails.to.length > 0) {
          const subject = `Issue Resolved: ${issue.site_name} (${issue.site_code}) - ${issue.category}`;
          const body = `Hello,\n\nThe site acquisition issue has been resolved.\n\nSite Details:\nSite Name: ${issue.site_name}\nSite ID: ${issue.site_code}\nLocation: ${issue.site_location}\n\nOriginal Report:\nReported By: ${issue.reporter_name}\nDepartment: ${issue.reporter_department}\nDate Reported: ${new Date(issue.date_reported).toLocaleString()}\nIssue Category: ${issue.category}\nIssue Description: ${issue.description}\n\nResolution Details:\nOfficer Attending: ${form.officerName}\nRoot Cause: ${form.rootCause}\nAction Taken: ${form.actionTaken}\nResolution Status: Resolved\nDate Closed: ${new Date().toLocaleString()}\n\nAll updates are available in the Site Acquisition Web App.\n\nRegards,\n${form.officerName}\nSAQ Team`;
          await logEmail(issue.id, 'issue_resolved', emails.to, emails.cc, subject, body);
        }
      }

      toast.success('Issue updated successfully');
      onUpdated?.();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Update failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b">
          <div>
            <h2 className="text-lg font-bold text-foreground">Issue Details</h2>
            <p className="text-xs text-muted-foreground mt-0.5">{issue.site_name} ({issue.site_code})</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-muted transition-colors">
            <X size={18} className="text-muted-foreground" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* Status & Priority badges */}
          <div className="flex gap-2 flex-wrap">
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[issue.status] || ''}`}>
              {issue.status}
            </span>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${priorityColors[issue.priority] || ''}`}>
              {issue.priority} Priority
            </span>
            <span className="text-xs text-muted-foreground ml-auto">
              Reported: {new Date(issue.date_reported).toLocaleDateString()}
            </span>
          </div>

          {/* Original Report */}
          <div className="rounded-lg bg-muted/50 p-4 space-y-2">
            <p className="text-xs font-medium text-muted-foreground uppercase">Original Report</p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div><span className="text-muted-foreground">Reporter:</span> <span className="text-foreground font-medium">{issue.reporter_name}</span></div>
              <div><span className="text-muted-foreground">Department:</span> <span className="text-foreground">{issue.reporter_department || 'N/A'}</span></div>
              <div><span className="text-muted-foreground">Category:</span> <span className="text-foreground">{issue.category}</span></div>
              <div><span className="text-muted-foreground">Location:</span> <span className="text-foreground">{issue.site_location}</span></div>
            </div>
            <div className="pt-2 border-t border-border">
              <p className="text-xs text-muted-foreground mb-1">Description:</p>
              <p className="text-sm text-foreground">{issue.description}</p>
            </div>
          </div>

          {/* Officer Response Section */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-foreground flex items-center gap-2">
              <CheckCircle size={16} className="text-primary" /> Officer Response
            </p>

            <div>
              <label className="form-label">Officer Name <span className="text-destructive">*</span></label>
              <input className="form-input mt-1" value={form.officerName} onChange={e => setForm({ ...form, officerName: e.target.value })} placeholder="Your name" />
            </div>

            <div>
              <label className="form-label">Root Cause</label>
              <textarea className="form-input mt-1 min-h-[70px]" value={form.rootCause} onChange={e => setForm({ ...form, rootCause: e.target.value })} placeholder="Identify the root cause..." />
            </div>

            <div>
              <label className="form-label">Action Taken</label>
              <textarea className="form-input mt-1 min-h-[70px]" value={form.actionTaken} onChange={e => setForm({ ...form, actionTaken: e.target.value })} placeholder="Describe the action taken..." />
            </div>

            {/* Photos */}
            <div>
              <label className="form-label flex items-center gap-1"><Camera size={14} /> Photos / Evidence</label>
              <div className="mt-1 flex gap-2 flex-wrap">
                {photos.map(p => (
                  <a key={p.id} href={p.photo_url} target="_blank" rel="noopener noreferrer" className="w-20 h-20 rounded-md border overflow-hidden hover:opacity-80 transition-opacity">
                    <img src={p.photo_url} alt={p.caption || 'Evidence'} className="w-full h-full object-cover" />
                  </a>
                ))}
                <label className="w-20 h-20 rounded-md border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted/50 transition-colors">
                  {uploading ? <Clock size={20} className="text-muted-foreground animate-spin" /> : <Upload size={20} className="text-muted-foreground" />}
                  <input type="file" className="hidden" accept="image/*" multiple onChange={handlePhotoUpload} disabled={uploading} />
                </label>
              </div>
            </div>

            {/* Status */}
            <div>
              <label className="form-label">Status</label>
              <select className="form-input mt-1" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
                {statusOptions.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="p-5 border-t flex gap-2 justify-end">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={handleUpdate} disabled={loading} className="btn-primary gap-2">
            {loading ? 'Saving...' : form.status === 'Resolved' ? 'Close Issue' : 'Update Issue'}
          </button>
        </div>
      </div>
    </div>
  );
}
