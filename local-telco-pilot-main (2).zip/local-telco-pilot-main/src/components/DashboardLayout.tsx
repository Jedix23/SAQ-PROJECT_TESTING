import { Navigate, Outlet } from 'react-router-dom';
import { isAuthenticated } from '@/lib/store';
import AppSidebar from './AppSidebar';

export default function DashboardLayout() {
  if (!isAuthenticated()) return <Navigate to="/login" replace />;
  return (
    <div className="flex min-h-screen w-full">
      <AppSidebar />
      <main className="flex-1 lg:ml-0 overflow-auto pt-14 lg:pt-0">
        <div className="p-4 md:p-6 lg:p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
