export interface Site {
  id: string;
  name: string;
  code: string;
  province: string;
  address: string;
  latitude: string;
  longitude: string;
  landType: string;
  lessorId: string;
  status: 'Active' | 'Pending' | 'Inactive';
  buildStatus: string;
  associatedUser: string;
  associatedEmail: string;
}

export interface Lessor {
  id: string;
  fullName: string;
  isGuardian: boolean;
  address: string;
  phone: string;
  mobile: string;
  fax: string;
  tinNumber: string;
  bankName?: string;
  bankBranch?: string;
  bankAccount?: string;
  bankAccountName?: string;
  guardianName?: string;
  guardianAccountName?: string;
  guardianAccountNumber?: string;
  guardianBankName?: string;
  guardianBranch?: string;
}

export interface Lease {
  id: string;
  siteId: string;
  lessorId: string;
  startDate: string;
  endDate: string;
  leaseTerm: string;
  monthlyPayment: string;
  gstApplicable: boolean;
  rentalRate: string;
  installments: string;
  amountPayable: string;
  rentalIncrease: string;
  sgRate: string;
  sgStartDate: string;
  specialRemarks: string;
  pdfData?: string;
  pdfName?: string;
  escalationType?: 'None' | 'CPI' | 'Fixed';
  escalationStartYear?: number;
  escalationRate?: number;
  escalationInterval?: number;
}

export interface Payment {
  id: string;
  leaseId: string;
  siteId: string;
  lessorId: string;
  amount: string;
  dueDate: string;
  paidDate?: string;
  status: 'Paid' | 'Pending' | 'Overdue';
  month: string;
  year: string;
}
