import { supabase } from '@/integrations/supabase/client';

export interface SiteIssue {
  id: string;
  site_id: string;
  site_name: string;
  site_code: string | null;
  site_location: string | null;
  reporter_name: string;
  reporter_department: string | null;
  category: string;
  description: string;
  priority: string;
  status: string;
  officer_name: string | null;
  root_cause: string | null;
  action_taken: string | null;
  date_reported: string;
  date_assigned: string | null;
  date_closed: string | null;
  created_at: string;
  updated_at: string;
}

export interface IssuePhoto {
  id: string;
  issue_id: string;
  photo_url: string;
  caption: string | null;
}

export interface IssueCategory {
  id: string;
  name: string;
}

export interface Department {
  id: string;
  name: string;
}

export interface DepartmentEmail {
  id: string;
  department_id: string;
  email: string;
  is_boss: boolean;
  label: string | null;
}

export interface CategoryDepartmentMap {
  id: string;
  category_id: string;
  department_id: string;
}

// Issue Categories
export async function fetchCategories(): Promise<IssueCategory[]> {
  const { data, error } = await supabase.from('issue_categories').select('*').order('name');
  if (error) throw error;
  return data || [];
}

export async function addCategory(name: string) {
  const { error } = await supabase.from('issue_categories').insert({ name });
  if (error) throw error;
}

export async function deleteCategory(id: string) {
  const { error } = await supabase.from('issue_categories').delete().eq('id', id);
  if (error) throw error;
}

// Departments
export async function fetchDepartments(): Promise<Department[]> {
  const { data, error } = await supabase.from('departments').select('*').order('name');
  if (error) throw error;
  return data || [];
}

export async function addDepartment(name: string) {
  const { error } = await supabase.from('departments').insert({ name });
  if (error) throw error;
}

export async function deleteDepartment(id: string) {
  const { error } = await supabase.from('departments').delete().eq('id', id);
  if (error) throw error;
}

// Department Emails
export async function fetchDepartmentEmails(departmentId?: string): Promise<DepartmentEmail[]> {
  let query = supabase.from('department_emails').select('*').order('is_boss', { ascending: false });
  if (departmentId) query = query.eq('department_id', departmentId);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export async function addDepartmentEmail(departmentId: string, email: string, isBoss: boolean, label?: string) {
  const { error } = await supabase.from('department_emails').insert({ department_id: departmentId, email, is_boss: isBoss, label });
  if (error) throw error;
}

export async function deleteDepartmentEmail(id: string) {
  const { error } = await supabase.from('department_emails').delete().eq('id', id);
  if (error) throw error;
}

// Category-Department Mapping
export async function fetchCategoryDepartmentMap(): Promise<CategoryDepartmentMap[]> {
  const { data, error } = await supabase.from('category_department_map').select('*');
  if (error) throw error;
  return data || [];
}

export async function setCategoryDepartment(categoryId: string, departmentId: string) {
  // Remove existing mapping for this category first
  await supabase.from('category_department_map').delete().eq('category_id', categoryId);
  const { error } = await supabase.from('category_department_map').insert({ category_id: categoryId, department_id: departmentId });
  if (error) throw error;
}

// Site Issues
export async function fetchIssues(filters?: { status?: string; priority?: string; siteId?: string }): Promise<SiteIssue[]> {
  let query = supabase.from('site_issues').select('*').order('date_reported', { ascending: false });
  if (filters?.status && filters.status !== 'All') query = query.eq('status', filters.status);
  if (filters?.priority && filters.priority !== 'All') query = query.eq('priority', filters.priority);
  if (filters?.siteId) query = query.eq('site_id', filters.siteId);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export async function createIssue(issue: Omit<SiteIssue, 'id' | 'created_at' | 'updated_at'>): Promise<SiteIssue> {
  const { data, error } = await supabase.from('site_issues').insert(issue).select().single();
  if (error) throw error;
  return data;
}

export async function updateIssue(id: string, updates: Partial<SiteIssue>): Promise<SiteIssue> {
  const { data, error } = await supabase.from('site_issues').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

// Issue Photos
export async function fetchIssuePhotos(issueId: string): Promise<IssuePhoto[]> {
  const { data, error } = await supabase.from('issue_photos').select('*').eq('issue_id', issueId);
  if (error) throw error;
  return data || [];
}

export async function uploadIssuePhoto(issueId: string, file: File, caption?: string): Promise<string> {
  const ext = file.name.split('.').pop();
  const path = `${issueId}/${crypto.randomUUID()}.${ext}`;
  const { error: uploadError } = await supabase.storage.from('issue-photos').upload(path, file);
  if (uploadError) throw uploadError;
  const { data: urlData } = supabase.storage.from('issue-photos').getPublicUrl(path);
  const photoUrl = urlData.publicUrl;
  const { error } = await supabase.from('issue_photos').insert({ issue_id: issueId, photo_url: photoUrl, caption });
  if (error) throw error;
  return photoUrl;
}

// Email log
export async function logEmail(issueId: string, emailType: string, recipients: string[], ccRecipients: string[], subject: string, body: string) {
  const { error } = await supabase.from('issue_email_log').insert({
    issue_id: issueId,
    email_type: emailType,
    recipients,
    cc_recipients: ccRecipients,
    subject,
    body,
  });
  if (error) throw error;
}

// Get emails for a category's responsible department
export async function getEmailsForCategory(categoryName: string): Promise<{ to: string[]; cc: string[] }> {
  const categories = await fetchCategories();
  const cat = categories.find(c => c.name === categoryName);
  if (!cat) return { to: [], cc: [] };
  
  const mappings = await fetchCategoryDepartmentMap();
  const mapping = mappings.find(m => m.category_id === cat.id);
  if (!mapping) return { to: [], cc: [] };
  
  const emails = await fetchDepartmentEmails(mapping.department_id);
  return {
    to: emails.filter(e => e.is_boss).map(e => e.email),
    cc: emails.filter(e => !e.is_boss).map(e => e.email),
  };
}
