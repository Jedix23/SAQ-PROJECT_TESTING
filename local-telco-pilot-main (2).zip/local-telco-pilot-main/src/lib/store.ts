import { Site, Lessor, Lease, Payment } from './types';

const KEYS = { sites: 'tsm_sites', lessors: 'tsm_lessors', leases: 'tsm_leases', payments: 'tsm_payments', auth: 'tsm_auth', seeded: 'tsm_seeded_v3' };

function get<T>(key: string): T[] {
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; }
}
function set<T>(key: string, data: T[]) { localStorage.setItem(key, JSON.stringify(data)); }

// Auth
export const login = (u: string, p: string) => {
  if (u === 'admin' && p === 'admin123') { localStorage.setItem(KEYS.auth, 'true'); return true; }
  return false;
};
export const logout = () => localStorage.removeItem(KEYS.auth);
export const isAuthenticated = () => localStorage.getItem(KEYS.auth) === 'true';

// Sites
export const getSites = (): Site[] => get(KEYS.sites);
export const saveSites = (s: Site[]) => set(KEYS.sites, s);
export const addSite = (s: Site) => { const all = getSites(); all.push(s); saveSites(all); };
export const updateSite = (s: Site) => { saveSites(getSites().map(x => x.id === s.id ? s : x)); };
export const deleteSite = (id: string) => { saveSites(getSites().filter(x => x.id !== id)); };

// Lessors
export const getLessors = (): Lessor[] => get(KEYS.lessors);
export const saveLessors = (l: Lessor[]) => set(KEYS.lessors, l);
export const addLessor = (l: Lessor) => { const all = getLessors(); all.push(l); saveLessors(all); };
export const updateLessor = (l: Lessor) => { saveLessors(getLessors().map(x => x.id === l.id ? l : x)); };
export const deleteLessor = (id: string) => { saveLessors(getLessors().filter(x => x.id !== id)); };

// Leases
export const getLeases = (): Lease[] => get(KEYS.leases);
export const saveLeases = (l: Lease[]) => set(KEYS.leases, l);
export const addLease = (l: Lease) => { const all = getLeases(); all.push(l); saveLeases(all); };
export const updateLease = (l: Lease) => { saveLeases(getLeases().map(x => x.id === l.id ? l : x)); };
export const deleteLease = (id: string) => { saveLeases(getLeases().filter(x => x.id !== id)); };

// Payments
export const getPayments = (): Payment[] => get(KEYS.payments);
export const savePayments = (p: Payment[]) => set(KEYS.payments, p);
export const addPayment = (p: Payment) => { const all = getPayments(); all.push(p); savePayments(all); };
export const updatePayment = (p: Payment) => { savePayments(getPayments().map(x => x.id === p.id ? p : x)); };
export const deletePayment = (id: string) => { savePayments(getPayments().filter(x => x.id !== id)); };

// Lease alert helpers
export function getLeaseAlerts() {
  const leases = getLeases();
  const sites = getSites();
  const now = new Date();
  const alerts: { lease: Lease; siteName: string; daysLeft: number; severity: 'critical' | 'warning' | 'info' }[] = [];

  leases.forEach(l => {
    if (!l.endDate) return;
    const end = new Date(l.endDate);
    const diff = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diff > 365 || diff < 0) return;
    const site = sites.find(s => s.id === l.siteId);
    const severity = diff <= 90 ? 'critical' : diff <= 180 ? 'warning' : 'info';
    alerts.push({ lease: l, siteName: site?.name || 'Unknown', daysLeft: diff, severity });
  });

  return alerts.sort((a, b) => a.daysLeft - b.daysLeft);
}

// Calculate escalated rent
export function calculateEscalatedRent(lease: Lease): { year: number; amount: number }[] {
  const base = parseFloat(lease.monthlyPayment.replace(/[^0-9.]/g, '')) || 0;
  const termYears = parseInt(lease.leaseTerm) || 10;
  const results: { year: number; amount: number }[] = [];

  if (!lease.escalationType || lease.escalationType === 'None') {
    for (let y = 1; y <= termYears; y++) results.push({ year: y, amount: base });
    return results;
  }

  const startYear = lease.escalationStartYear || 6;
  const rate = (lease.escalationRate || 0) / 100;
  const interval = lease.escalationInterval || 1;
  let current = base;

  for (let y = 1; y <= termYears; y++) {
    if (y >= startYear && (y - startYear) % interval === 0 && y > 1) {
      current = current * (1 + rate);
    }
    results.push({ year: y, amount: Math.round(current * 100) / 100 });
  }
  return results;
}

// CSV Export
export function exportToCSV(data: Record<string, any>[], filename: string) {
  if (data.length === 0) return;
  const headers = Object.keys(data[0]);
  const csv = [
    headers.join(','),
    ...data.map(row => headers.map(h => {
      const val = String(row[h] ?? '').replace(/"/g, '""');
      return `"${val}"`;
    }).join(','))
  ].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Seed
export function seedData() {
  if (localStorage.getItem(KEYS.seeded)) return;

  const lessors: Lessor[] = [
    { id: 'l1', fullName: 'Meta Jangiko', isGuardian: false, address: 'P.O. Box 2033, Lae, Morobe Province, PNG', phone: '71843951', mobile: '71843951', fax: 'N/A', tinNumber: 'N/A', bankName: 'BSP', bankBranch: 'Lae Branch', bankAccount: '1001234567', bankAccountName: 'Meta Jangiko' },
    { id: 'l2', fullName: 'John Kaupa', isGuardian: true, address: 'P.O. Box 445, Mt Hagen, WHP', phone: '72345678', mobile: '72345678', fax: 'N/A', tinNumber: '123456789', bankName: 'Westpac', bankBranch: 'Mt Hagen', bankAccount: '2009876543', bankAccountName: 'John Kaupa', guardianName: 'Peter Kaupa', guardianAccountName: 'Peter Kaupa', guardianAccountNumber: '3001112233', guardianBankName: 'BSP', guardianBranch: 'Mt Hagen' },
    { id: 'l3', fullName: 'Mary Tokain', isGuardian: false, address: 'Section 21, Lot 5, Boroko, NCD', phone: '3251234', mobile: '70123456', fax: 'N/A', tinNumber: 'N/A', bankName: 'Kina Bank', bankBranch: 'Boroko', bankAccount: '4005556677', bankAccountName: 'Mary Tokain' },
  ];

  const sites: Site[] = [
    { id: 's1', name: '11 Mile', code: 'VP1001', province: 'Morobe', address: 'Portion 468, 11 Mile', latitude: '-6.7340', longitude: '147.0030', landType: 'Customary', lessorId: 'l1', status: 'Active', buildStatus: 'N/A', associatedUser: 'Patrick Kavapo', associatedEmail: 'patrick.kavapo@vodafone.com.pg' },
    { id: 's2', name: 'Hagen Central', code: 'VP2056', province: 'Western Highlands', address: 'Lot 12, Hagen Drive', latitude: '-5.8601', longitude: '144.2306', landType: 'State', lessorId: 'l2', status: 'Active', buildStatus: 'Complete', associatedUser: 'James Wai', associatedEmail: 'james.wai@vodafone.com.pg' },
    { id: 's3', name: 'Boroko Tower', code: 'VP3012', province: 'NCD', address: 'Section 21, Boroko', latitude: '-9.4578', longitude: '147.1846', landType: 'State', lessorId: 'l3', status: 'Pending', buildStatus: 'In Progress', associatedUser: 'Anna Rupa', associatedEmail: 'anna.rupa@vodafone.com.pg' },
    { id: 's4', name: 'Kimbe Town', code: 'VP4078', province: 'West New Britain', address: 'Lot 3, Kimbe', latitude: '-5.5510', longitude: '150.1430', landType: 'Customary', lessorId: 'l1', status: 'Active', buildStatus: 'Complete', associatedUser: 'Patrick Kavapo', associatedEmail: 'patrick.kavapo@vodafone.com.pg' },
    { id: 's5', name: 'Kokopo Ridge', code: 'VP5034', province: 'East New Britain', address: 'Section 5, Kokopo', latitude: '-4.3418', longitude: '152.2740', landType: 'Customary', lessorId: 'l2', status: 'Pending', buildStatus: 'N/A', associatedUser: 'James Wai', associatedEmail: 'james.wai@vodafone.com.pg' },
  ];

  const leases: Lease[] = [
    { id: 'le1', siteId: 's1', lessorId: 'l1', startDate: '2021-02-01', endDate: '2031-02-01', leaseTerm: '10', monthlyPayment: 'K666.67', gstApplicable: true, rentalRate: 'K0.10', installments: 'K2.00', amountPayable: 'K0.11', rentalIncrease: 'K0.10', sgRate: 'N/A', sgStartDate: '2021-02-01', specialRemarks: 'Term = 10 years', escalationType: 'CPI', escalationStartYear: 6, escalationRate: 3, escalationInterval: 1 },
    { id: 'le2', siteId: 's2', lessorId: 'l2', startDate: '2020-06-15', endDate: '2030-06-15', leaseTerm: '10', monthlyPayment: 'K1,200.00', gstApplicable: true, rentalRate: 'K0.15', installments: 'K3.00', amountPayable: 'K1,200.15', rentalIncrease: 'K0.12', sgRate: '5%', sgStartDate: '2020-06-15', specialRemarks: 'Auto-renewal clause', escalationType: 'Fixed', escalationStartYear: 6, escalationRate: 5, escalationInterval: 2 },
    { id: 'le3', siteId: 's3', lessorId: 'l3', startDate: '2022-01-01', endDate: '2027-01-01', leaseTerm: '5', monthlyPayment: 'K800.00', gstApplicable: false, rentalRate: 'K0.08', installments: 'K1.50', amountPayable: 'K800.08', rentalIncrease: 'K0.05', sgRate: 'N/A', sgStartDate: '2022-01-01', specialRemarks: '', escalationType: 'None' },
  ];

  const payments: Payment[] = [
    { id: 'p1', leaseId: 'le1', siteId: 's1', lessorId: 'l1', amount: 'K666.67', dueDate: '2025-01-01', paidDate: '2025-01-03', status: 'Paid', month: 'January', year: '2025' },
    { id: 'p2', leaseId: 'le1', siteId: 's1', lessorId: 'l1', amount: 'K666.67', dueDate: '2025-02-01', paidDate: '2025-02-02', status: 'Paid', month: 'February', year: '2025' },
    { id: 'p3', leaseId: 'le1', siteId: 's1', lessorId: 'l1', amount: 'K666.67', dueDate: '2025-03-01', status: 'Pending', month: 'March', year: '2025' },
    { id: 'p4', leaseId: 'le2', siteId: 's2', lessorId: 'l2', amount: 'K1,200.00', dueDate: '2025-01-15', paidDate: '2025-01-15', status: 'Paid', month: 'January', year: '2025' },
    { id: 'p5', leaseId: 'le2', siteId: 's2', lessorId: 'l2', amount: 'K1,200.00', dueDate: '2025-02-15', status: 'Overdue', month: 'February', year: '2025' },
    { id: 'p6', leaseId: 'le3', siteId: 's3', lessorId: 'l3', amount: 'K800.00', dueDate: '2025-03-01', status: 'Pending', month: 'March', year: '2025' },
  ];

  saveLessors(lessors);
  saveSites(sites);
  saveLeases(leases);
  savePayments(payments);
  localStorage.setItem(KEYS.seeded, 'true');
}
