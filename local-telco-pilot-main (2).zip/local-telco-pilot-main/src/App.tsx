import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { seedData } from '@/lib/store';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';
import Sites from '@/pages/Sites';
import Lessors from '@/pages/Lessors';
import Leases from '@/pages/Leases';
import Payments from '@/pages/Payments';
import Issues from '@/pages/Issues';
import AdminSettings from '@/pages/AdminSettings';
import DashboardLayout from '@/components/DashboardLayout';
import NotFound from '@/pages/NotFound';

seedData();

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route element={<DashboardLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/sites" element={<Sites />} />
        <Route path="/lessors" element={<Lessors />} />
        <Route path="/leases" element={<Leases />} />
        <Route path="/payments" element={<Payments />} />
        <Route path="/issues" element={<Issues />} />
        <Route path="/admin-settings" element={<AdminSettings />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  </BrowserRouter>
);

export default App;
